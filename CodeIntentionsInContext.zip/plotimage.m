
function plotimage(impl)

figure
subplot(2, 2, 1)
imagesc(squeeze(mean(impl, 1)))
subplot(2, 2, 2)
imagesc(squeeze(mean(impl, 2)))
subplot(2, 2, 3)
imagesc(squeeze(mean(impl, 3)))