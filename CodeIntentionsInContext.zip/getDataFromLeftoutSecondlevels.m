function extracted_CV_data = getDataFromLeftoutSecondlevels (cfg)

% extract 2nd level CV results

%% load DAs for each subject

display('Loading single subject DAs')

same_basedir = [cfg.baseDir, 'data/secondLevel/sameReasonSameContext/']; 
crossReason_basedir = [cfg.baseDir, 'secondLevel/crossReason/'];
crossContext_basedir = [cfg.baseDir, 'secondLevel/crossContext/'];
crossReasonCrossContext_basedir = [cfg.baseDir, 'secondLevel/crossReasonCrossContext/'];

DA_results = [];

for sn_ind = 1:length(cfg.subsToDo)
    curr_sn = cfg.subsToDo(sn_ind);
    curr_data = [];
    curr_data.sub = curr_sn;
    for condition = 1 : length(cfg.conditionNames)
        
        curr_data.fullfname = fullfile(cfg.baseDir, 'data', ['sub' , num2str(curr_sn, '%02i')], 'NIFTI/results/MVPA_allCombinations/', ['average', cfg.conditionNames{condition}, '.nii']);

        display(['Loading ' curr_data.fullfname]);
        curr_data.hdr = spm_vol(curr_data.fullfname);
        curr_data.vol = spm_read_vols(curr_data.hdr);
        DA_results.(cfg.conditionNames{condition}).sub(sn_ind) = curr_data;
    end
end

%% Functional-Anatomical Identity & order ROIs

WFUregions = cfg.selectedROIs;

%% Start extraction

p = '.001';
correction = 'uncorr';
    
func_ana_ROIs = [];
% roi_ind = 0; % init
for condition = cfg.conditionNames
    
    current_basedir = [cfg.baseDir, 'secondLevel/', condition{1}, '/'];
    
    for roi = cfg.selectedROIs
        func_ana_ROIs.(roi{1}).name = roi{1};
        func_ana_ROIs.(roi{1}).dir = fullfile(same_basedir, 'faROIs', roi{1});
        
        if ~exist(func_ana_ROIs.(roi{1}).dir, 'dir')
            error('Can''t find directory %s', func_ana_ROIs.(roi{1}).dir)
        end
        
        for sn_ind = 1:length(cfg.subsToDo)
            curr_sn = cfg.subsToDo(sn_ind);
            
            filemask = ['mask_sub' num2str(curr_sn, '%02i'), '.*nii'];
            curr_file = spm_select('List', func_ana_ROIs.(roi{1}).dir, filemask);
            
            curr_data = [];
            curr_data.sub = curr_sn;
            if isempty(curr_file)
                display(['WFUPickAtlas_' roi{1} '_p0' p '_' correction 'sub' int2str(curr_sn) ': No 2nd level CV functional anatomical region found'])
                curr_data.fileexists = 0;
            elseif size(curr_file, 1) == 1
                display(['WFUPickAtlas_' roi{1} '_p0' p '_' correction 'sub' int2str(curr_sn) ': 2nd level CV functional anatomical region found: ' curr_file])
                curr_data.fileexists = 1;
                curr_data.filename = curr_file;
                display(['Loading ' fullfile(func_ana_ROIs.(roi{1}).dir, curr_file)])
                curr_data.hdr = spm_vol(fullfile(func_ana_ROIs.(roi{1}).dir, curr_file));
                curr_data.vol = spm_read_vols(curr_data.hdr);
                curr_data.type = condition;
            else
                error(['Could not uniquely determine the file for ' 'WFUPickAtlas_' roi{1} '_p0' p '_' correction 'sub' int2str(curr_sn)])
            end
            
            func_ana_ROIs.(roi{1}).sub{sn_ind} = curr_data;
            
        end
    end
end


%% extract left out subject data from rois

display('extract left out subject data from rois')

% extract data for all rois
for roi = fieldnames(func_ana_ROIs)'
    roi = roi{1};
    display(['Extracting for ' roi])
    
    for sn_ind = 1:length(cfg.subsToDo)
        curr_sn = cfg.subsToDo(sn_ind);
        
        display(sprintf('%s, p%s %s, Sub%02i', roi, p, correction, curr_sn))
        
        curr_roi = func_ana_ROIs.(roi).sub{sn_ind};
        
        % check if ROI exists
        result = [];
        result.sn = curr_sn;
        if ~curr_roi.fileexists
            result.ROI.available = 0;
            
            result.sameReasonSameContxt.all = NaN;
            result.sameReasonSameContext.mean = NaN;
            % not quite right, but ok as a marker that order is not
            % there
            result.crossReason.all = NaN;
            result.crossReason.mean = NaN;
            result.crossContext.all = NaN;
            result.crossContext.mean = NaN;
            result.crossReasonCrossContext.all = NaN;
            result.crossReasonCrossContext.mean = NaN;
        else
            % check that cub nr is ok
            if DA_results.sameReasonSameContext.sub(sn_ind).sub ~= curr_sn || curr_roi.sub ~= curr_sn
                error('different subject numbers between curr_sn, DA image and/or ROI, aborting')
            end
            
            curr_sub_da.sameReasonSameContext = DA_results.sameReasonSameContext.sub(sn_ind).vol;
            curr_sub_da.crossReason = DA_results.crossReason.sub(sn_ind).vol;
            curr_sub_da.crossContext = DA_results.crossContext.sub(sn_ind).vol;
            curr_sub_da.crossReasonCrossContext = DA_results.crossReasonCrossContext.sub(sn_ind).vol;
            
            % results available, do the stuff
            
            result.ROI.available = 1;
            result.ROI.fname = curr_roi.filename;
            result.ROI.dir = func_ana_ROIs.(roi).dir;
            
            for condition = 1 : length(cfg.conditionNames)
                result.(cfg.conditionNames{condition}).all = curr_sub_da.(cfg.conditionNames{condition})(curr_roi.vol>0);
                result.(cfg.conditionNames{condition}).mean = mean(result.(cfg.conditionNames{condition}).all);
                result.(cfg.conditionNames{condition}).DA_fullname = DA_results.(cfg.conditionNames{condition}).sub(sn_ind).fullfname;
            end
        end
        extracted_CV_data.(roi).(correction).(['p' p(2:end)]).sub{sn_ind} = result;
        
    end
end


% done
display('Extraction done, saving files left')

%% save result

if exist(cfg.resultsFolder) == 0
    mkdir(cfg.resultsFolder)
end;
    

fullresultname = fullfile(cfg.resultsFolder, 'extracted_CV_data_seleted_allROIs.mat');
display(['Saving file to ' fullresultname])
save(fullresultname, 'extracted_CV_data')

display('Script finished')