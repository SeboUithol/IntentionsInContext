function combineClusters(cfg) 
% This function combines multiple clusters into one and saves it as a .nii file
%
%   IN
%   cfg.clusterDir
%   cfg.fileName
%
%   OUT
%   Cluster image in .nii format


contentClusterDir = dir(fullfile(cfg.clusterDir,'*.nii'));
clusterNames = {contentClusterDir.name};

if length(contentClusterDir)>0
    
    % Load first cluster
    fileName = fullfile(cfg.clusterDir, clusterNames(1));
    hdr = spm_vol(fileName{1});
    vol = spm_read_vols(hdr);
    allClusters = vol;
    
    % Add remaining Clusters
    
    for cluster = 2 : length(clusterNames)
        currentCluster = fullfile(cfg.clusterDir, clusterNames(cluster));
        hdr = spm_vol(fileName{1});
        vol = spm_read_vols(hdr);
        allClusters = allClusters | vol;
    end
    
    % save cluster
    display(['Saving result to ', cfg.clusterDir, cfg.fileName]);
    res_hdr = hdr;
    res_hdr.fname = [cfg.clusterDir, cfg.fileName];
    
    spm_write_vol(res_hdr, allClusters);
end;