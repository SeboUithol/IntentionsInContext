% function mat = get_rank(mat, nanval)
%
% Get the rank of a matrix (not the mathematical rank, but the order of
% elements). Equal elements have the same index (the highest among them).
%
% By default, nans are kept nans. If you like, you can specify a value for
% them in the nanval argument (e.g. -1). Internally nans get the highest
% values, which causes that the ranks are only among the values that really
% exist (e.g. if the matrix contains 16 entries, and 4 are nans, the
% highest rank value will be 12). 
%
% Kai, 2015/10/14

% Code adapted from http://www.mathworks.com/matlabcentral/newsreader/view_thread/252513

function mat = get_rank(mat, nanval)

arenans = isnan(mat);
[B, I] = sort(mat(:));
first = find([true; diff(B)>1e-16]); % put tiny differences to as 0 (to ignore numerical problems)
B(:) = 0;
B(first) = diff([0; first]);
mat(I) = cumsum(B);

if nargin == 1
    mat(arenans) = nan;
else
    mat(arenans) = nanval;
end
