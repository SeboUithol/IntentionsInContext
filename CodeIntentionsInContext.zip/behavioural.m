%% Import PsychoPy log and Create Onset Matrix
subjects = 32; % Total number of subjects
excludeSubjects = [3,4, 17, 27, 28, 32]; % subjects left out of the analysis

subsToDo = [];
for subject = 1 : subjects
    skip = ismember (subject, excludeSubjects);
    if skip == 0
        subsToDo(end+1) = subject;
    end;
end

baseDir = '/Users/SeboUithol/Documents/BCAN/intentionsContext/';

%% Score


answers = zeros(length(subsToDo), 2);

for subject = 1 : length(subsToDo)
    subDir = [baseDir, 'data/sub', num2str(subsToDo(subject), '%02i'), '/NIFTI/'];
    
    filename = sprintf('data/PsychoPyLogs/sub%02i.xlsx', subject);
    disp(['Reading PsychoPy data for subject ', int2str(subject)])
    
    
    trials = 160;
    trialsPerRun = 32;
    runs = 5;
    conditions = 8;
    psychopyLog = xlsread ([baseDir, filename], 'A2:M161');
    for trial = 1 : trials
        if psychopyLog (trial, 6) == psychopyLog (trial, 7) % Only the right trials
            answers (subject, 1) = answers (subject, 1) + 1; % Right answers
        else
            answers (subject, 2) = answers (subject, 2) + 1; % Wrong answers
        end
        %psychopyLog (trial, 14) = (psychopyLog(trial, 4)-1) * 4 +psychopyLog(trial, 5);
    end
    
    answers (subject, 3) = (answers (subject, 1)/160) * 100; % Percentage correct

end

answers (subject + 1, 3) = mean (answers(:,3));

standardDeviation = std (answers(:,3));

for row = 1 : length(answers)
    answers(row, 4) = abs(answers (subject + 1, 3) - answers(row, 3)); 
end

answers(length(subsToDo) + 1, 4) = mean(answers(1:length(subsToDo), 4));

totalDiscarded = sum(answers(:,2));

%% RTs
RTs = zeros(length(subsToDo), 4);

for subject = 1 : length(subsToDo)
    subDir = [baseDir, 'data/sub', num2str(subsToDo(subject), '%02i'), '/NIFTI/'];
    
    filename = sprintf('data/PsychoPyLogs/sub%02i.xlsx', subsToDo(subject));
    disp(['Reading PsychoPy data for subject ', int2str(subsToDo(subject))])
    
    subjectRT = zeros(trials, conditions);
    psychopyLog = xlsread ([baseDir, filename], 'A2:M161');
    for condition = 1 : 4
        for trial = 1 : length(psychopyLog)
            if psychopyLog (trial, 5) == condition
                subjectRT(trial, condition) = psychopyLog (trial, 8);
            end
        RTs (subject, condition) = mean(nonzeros(subjectRT(:, condition)));
        end
    end
end

for condition = 1:4
    RTs(length(subsToDo)+1, condition) = mean(RTs(1:25,condition));
end
