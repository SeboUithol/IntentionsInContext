%% Convert ROIs back to subject space
%Use inverse of MNI conversion


function MNI2native(baseDir, subject, rois)

    subDir = [baseDir, 'data/sub', num2str(subject, '%02i'), '/NIFTI/'];
    structDir = [subDir, '/T1'];
    roiMNIDir = [baseDir, 'ROIsMNI/'];
    roiSubjectDir = [subDir, 'ROIs/'];
    mkdir (roiSubjectDir);
    for r = 1 : length(rois)
        roiFiles{r,1} = [roiMNIDir, 'MNI', rois{r}];
    end;
    clear r

    matlabbatch = {};
    matlabbatch{1}.spm.spatial.normalise.write.subj.def = cellstr(spm_select('FPList', structDir, 'iy.*.nii$'));
    matlabbatch{1}.spm.spatial.normalise.write.subj.resample = cellstr(roiFiles);
    matlabbatch{1}.spm.spatial.normalise.write.roptions.vox = [3 3 3.75]; %resample in same voxel size as native images
    
    spm_jobman('run',matlabbatch);
    
    nativeRoiFiles = cellstr(spm_select('FPList', roiMNIDir, '^w.*\.nii$'));

%   reslice to fit original scan
    matlabbatch = {};
    matlabbatch{1}.spm.spatial.realign.write.data(1) = {spm_select('FPList', [subDir, 'run1/'], '^mean.*\.nii$')};
    for r = 1 : length(rois)
        matlabbatch{1}.spm.spatial.realign.write.data(r+1,1) = nativeRoiFiles(r);
    end;
    matlabbatch{1}.spm.spatial.realign.write.roptions.which = [1 0];
    matlabbatch{1}.spm.spatial.realign.write.roptions.interp = 4;
    matlabbatch{1}.spm.spatial.realign.write.roptions.wrap = [0 0 0];
    matlabbatch{1}.spm.spatial.realign.write.roptions.mask = 1;
    matlabbatch{1}.spm.spatial.realign.write.roptions.prefix = 'r';
    
    spm_jobman('run',matlabbatch);

 %  copy file to subject folder
    nativeRoiFiles = cellstr(spm_select('FPList', roiMNIDir, '^rw.*\.nii$'));

    
    for r = 1 : length(rois)
        copyfile(fullfile(roiMNIDir, ['rwMNI', rois{r}]), fullfile(roiSubjectDir, rois{r}));
    end;

