%% Analysis parameters

% Subjects
subjects = 32; % Total number of subjects
excludeSubjects = [3,4, 17, 27, 28, 32]; % subjects left out of the analysis

subsToDo = [];
for subject = 1 : subjects
    skip = ismember (subject, excludeSubjects);
    if skip == 0
        subsToDo(end+1) = subject;
    end;
end;

% baseDir
%baseDir = getBaseDir;
baseDir = '/Users/SeboUithol/Documents/BCAN/intentionsContext/';
addpath(baseDir)
cd (baseDir)
dataDir = [baseDir, 'data/'];

conditionNames = {'sameReasonSameContext', 'crossReason', 'crossContext', 'crossReasonCrossContext'};
analyzeCondition = 3;

% Define sets
same = [1 6 11 16 17 22 27 32]; % ROI defining condition 
                                                 % to be tested 1
crossReason = [2 5 12 15 18 21 28 31]; % to be tested 2
crossContext = [3 8 9 14 19 24 25 30]; % to be tested 3
crossReasonCrossContext = [4 7 10 13 20 23 26 29]; % to be tested 4

allSets = [same; crossReason; crossContext; crossReasonCrossContext];

roiNames = {'parietal', 'premotor', 'prefrontal', 'cerebellum'};

% start spm
spm fmri

female = 0;
age = [];
for sub = subsToDo
   files = dir([dataDir, 'sub', num2str(sub, '%02i'), '/DICOM/001_AAHScout/*.dcm']); % Assuming all scanning starts with the head scout
   dicomHeader = dicominfo(fullfile(files(1).folder, files(1).name));
   if strcmp (dicomHeader.PatientSex, 'F') == 1
       female = female + 1;
   end
   age(end+1) = str2num(dicomHeader.PatientAge(1:3)); % Assuming patients no older than 999 years
end
clc
disp (['Total number of subjects is ', num2str(length(subsToDo)), ' Of which ', num2str(female), ' are female']);
disp (['Average age is ', num2str(round(mean(age), 1)), ' years, with a standard deviation of ', num2str(round(std(age),1)), ' years']);

%% GLM

clear cfg
cfg.baseDir = baseDir;
cfg.outputDir = 'GLMset10/';
cfg.subsToDo = subsToDo;

for subject = subsToDo
    firstLevelAnalysis(subject, cfg)
end


%% Decoding

for subject = subsToDo

    subDir = fullfile(baseDir, 'data', sprintf('sub%02i', subject), '/NIFTI/');
    %betaDir = fullfile(subDir, 'results/firstLevel/native/fullWithRegressors/');
    betaDir = fullfile(subDir, 'results/GLMset3/');

    
    clear cfg cfgDesign
    cfg             = decoding_defaults;
    cfg.baseDir     = baseDir;
    cfg.structDir   = [subDir, 'T1'];
    cfg.analysis    = 'searchlight';
    cfg.results.dir = [subDir, 'results/MVPA_allCombinationsSet3/'];
    % Ensure all designs are created twoway (see make_design_xclass_cv)
    cfg.files.twoway = 0; % Not twoway, because double loop below ensures that each set is used as training and test once in separate steps below
    % and make sure each set is saved in addition to the main result
    cfg.results.setwise = 1; %

    cfg.files.mask  = [betaDir, 'mask.nii'];
    cfg.results.output = {'accuracy_minus_chance'};
    regressor_names = design_from_spm(betaDir);
 
    % WITHIN CONTEXT DECODING
    labelnamesMaster =    {'BOD', 'BOC', 'BPK', 'BPR', 'SOD', 'SOC', 'SPK', 'SPR'};
    labelsMaster =        [ 1      1      2       2      1      1      2      2 ];
    xclassMaster1 =       [ 1      2      1       2      3      4      3      4 ];
    xclassMaster2 =       [ 1      2      2       1      3      4      4      3 ];
    
    index = 1;

    for flip = 1 : 2 
        if flip == 1
            xclassMaster = xclassMaster1;
        elseif flip == 2
            xclassMaster = xclassMaster2;
        end
        
        for trainxs = 1 : 4
            
            for testxs = 1 : 4 
                cfgDesign{index} = cfg;
                
                % Training
                xclass = xclassMaster;
                xclass(:) = nan;
                xclass(xclassMaster == trainxs) = trainxs;
                % Testing
                xclass(xclassMaster == testxs) = testxs;
                
                labels = labelsMaster(~isnan(xclass));
                labelnames = labelnamesMaster(~isnan(xclass));
                xclass = xclass(~isnan(xclass));
                
                % Bugfix: set training and testing labels in xclass
                xclass_tmp = xclass;
                % set trainxs to 1 and testxs to 2
                % smaller xclass used as training set in make_design_xclass
                xclass(xclass_tmp == trainxs) = 1;
                xclass(xclass_tmp == testxs ) = 2;
                
                cfgDesign{index} = decoding_describe_data(cfgDesign{index}, labelnames, labels, regressor_names, betaDir, xclass);
               
                if trainxs == testxs
                    cfgDesign{index}.files.xclass = [];
                    cfgDesign{index}.design = make_design_cv(cfgDesign{index});
                else
                    cfgDesign{index}.design = make_design_xclass_cv(cfgDesign{index}); 
                end
                
                
                index = index + 1;
            end
        end
    end
    
    % Combine designs
    cfg = combine_designs(cfgDesign); 
%    plot_design(cfg);

    % sorting training set should yield about 4x speedup
    % computations will not change
    cfg.design = sort_design(cfg.design);
%    plot_design(cfg);
    
    disp(['Decoding subject ', int2str(subject)])
    decodingIntention(cfg);

    % Convert results to MNI
    clear cfg
    cfg.baseDir = baseDir;
    cfg.resultsDir = [subDir, 'results/MVPA_allCombinationsSet10/'];
    cfg.structDir   = [subDir, 'T1'];
    normalizeSmoothDecoding(cfg, subject);
end

%% Second level per conditions over subjects
clear cfg 

cfg.dataDir     = dataDir; 
cfg.baseDir     = baseDir;
for condition = 1 : 4
    filenames   = {};
    cfg.filenames   = {};

    for sub = subsToDo
        inputDir    = [baseDir, '/data/sub', num2str(sub, '%02i'),'/NIFTI/results/MVPA_allCombinationsSet3/'];
        
        % Gather all images belonging to one condition (per subject)
        for set = 1 : length(allSets)
            filenames{end+1, 1} = [inputDir, 'wres_accuracy_minus_chance_set00', num2str(allSets(condition,set), '%02i'),'.nii'];
        end
        
        % Calculate average per condition
        
        clear matlabbatch
        outputName = ['average', conditionNames{condition}, '.nii'];
        matlabbatch{1}.spm.util.imcalc.input = filenames;
        matlabbatch{1}.spm.util.imcalc.output = outputName;
        matlabbatch{1}.spm.util.imcalc.outdir = {inputDir};
        matlabbatch{1}.spm.util.imcalc.expression = '(i1+i2+i3+i4+i5+i6+i7+i8)/8';
        matlabbatch{1}.spm.util.imcalc.var = struct('name', {}, 'value', {});
        matlabbatch{1}.spm.util.imcalc.options.dmtx = 0;
        matlabbatch{1}.spm.util.imcalc.options.mask = 0;
        matlabbatch{1}.spm.util.imcalc.options.interp = 1;
        matlabbatch{1}.spm.util.imcalc.options.dtype = 4;
        
        display (['writing ', outputName, ' to ', inputDir])
        spm_jobman('run',matlabbatch);
        
        filenames = {};

        cfg.filenames{end+1, 1} = fullfile(inputDir, outputName);
        
    end
    % Run the analysis per condition
    cfg.outputSubDir = [conditionNames{condition},'Set10/'];
    secondLevelAnalysis (cfg); 
end


%% Check significance of decoding results per condition

for condition = 1 : length(conditionNames)
    first_hdr = []; % Compare mat of all other headers against this
        
    % Second level directory, defined above. Suggestion: extract to
    %   function so it can be called here and there
    % cfg.outputDir   = ['sameContextSameReason/LOS', num2str(subject),'/'];
    
    %
    secondLevelDir = fullfile(dataDir, ['secondLevel/', conditionNames{condition}, '/']);
    % check header of result file
    hdr = spm_vol(fullfile(secondLevelDir, 'con_0001.nii'));
    if isempty(first_hdr)
        % store first header
        first_hdr = hdr;
    end
    %check_alignment(first_hdr, hdr);
    
    % get second level results
    clear cfg
    cfg.swd = secondLevelDir;
    cfg.pm = .001;
    cfg.identstring = 'Classification'; % should be t-contrast with c = [1]
    [result, volumes] = get_SPM_FWEc_results(cfg);
    
    vol    = zeros(volumes.FWEc05.xSPM.DIM(1:3)');
    Vind   = volumes.FWEc05.xSPM.XYZ(1,:) + volumes.FWEc05.xSPM.DIM(1)*(volumes.FWEc05.xSPM.XYZ(2,:)-1 + volumes.FWEc05.xSPM.DIM(2)*(volumes.FWEc05.xSPM.XYZ(3,:)-1));
    vol(Vind)= volumes.FWEc05.xSPM.Z.*(volumes.FWEc05.xSPM.Z > 0);
    spm_write_vol(hdr, vol);
end


%% Define ROIs based on the brainmap created using the SameSame contrast


clear cfg

cfg.baseDir = baseDir;
cfg.dataDir = dataDir;
cfg.ROIdir = [baseDir, 'ROIsMNI/marsbar_aal/'];

% Parietal
cfg.clusters{1}.name = roiNames{1};
cfg.clusters{1}.ROIs = {
    'rMNI_Angular_L_roi.nii'
    'rMNI_Angular_R_roi.nii'
    'rMNI_Postcentral_L_roi.nii'
    'rMNI_Postcentral_R_roi.nii'
    'rMNI_Parietal_Inf_L_roi.nii'
    'rMNI_Parietal_Inf_R_roi.nii'
    'rMNI_Parietal_Sup_L_roi.nii'
    'rMNI_Parietal_Sup_R_roi.nii'
    'rMNI_Precuneus_L_roi.nii'
    'rMNI_Precuneus_R_roi.nii'
};
% Premotor
cfg.clusters{2}.name = roiNames{2};
cfg.clusters{2}.ROIs = {
    'rMNI_Precentral_L_roi.nii'
    'rMNI_Precentral_R_roi.nii'
    'rMNI_Frontal_Inf_Oper_L_roi.nii'
    'rMNI_Frontal_Inf_Oper_R_roi.nii'
};
% Prefrontal
cfg.clusters{3}.name = roiNames{3};
cfg.clusters{3}.ROIs = {
    'rMNI_Frontal_Inf_Tri_L_roi.nii'
    'rMNI_Frontal_Inf_Tri_R_roi.nii'
};

% Cerebellum
cfg.clusters{4}.name = roiNames{4};
cfg.clusters{4}.ROIs = {
    'rMNI_Cerebelum_3_L_roi.nii'
    'rMNI_Cerebelum_3_R_roi.nii'
    'rMNI_Cerebelum_4_5_L_roi.nii'
    'rMNI_Cerebelum_4_5_R_roi.nii'
    'rMNI_Cerebelum_6_L_roi.nii'
    'rMNI_Cerebelum_6_R_roi.nii'
    'rMNI_Cerebelum_7b_L_roi.nii'
    'rMNI_Cerebelum_7b_R_roi.nii'
    'rMNI_Cerebelum_8_L_roi.nii'
    'rMNI_Cerebelum_8_R_roi.nii'
    'rMNI_Cerebelum_9_L_roi.nii'
    'rMNI_Cerebelum_9_R_roi.nii'
    'rMNI_Cerebelum_10_L_roi.nii'
    'rMNI_Cerebelum_10_R_roi.nii'
    'rMNI_Cerebelum_Crus1_L_roi.nii'
    'rMNI_Cerebelum_Crus1_R_roi.nii'
    'rMNI_Cerebelum_Crus2_L_roi.nii'
    'rMNI_Cerebelum_Crus2_R_roi.nii'
};

combineAALROIs(cfg)

% load functional activity from the sameSame analysis

subdir = [baseDir, 'data/secondLevel/sameReasonSameContextSet4/'];
CVresults = [];
curr_cv = [];
% load volume
fname = fullfile(subdir, 'con_0001.nii');
hdr = spm_vol(fname);
vol = spm_read_vols(hdr);

curr_cv.fname = fname;
curr_cv.hdr = hdr;
curr_cv.vol = vol;


% getting intersections between rois and CVresults

result = [];
respathbase = [cfg.dataDir, 'secondLevel/sameReasonSameContextSet3/faROIs/'];

for roi_name_ind = 1:length(roiNames)
    roi_name = roiNames{roi_name_ind};
    
    % get current ROI
    fname = fullfile([subdir, roi_name, '.nii']);
    hdr = spm_vol(fname);
    curr_roi = spm_read_vols(hdr);
 
    respath = fullfile(respathbase, roi_name);
    mkdir(respath)
    
    display(['Writing results to ' respath])
            
    % get intersection to current ROI
    intersect_vol = curr_roi & curr_cv.vol;
    size_vox_AAL_total = sum(curr_roi(:));
    size_vox_currcv_total = sum(curr_cv.vol(:));
    
    % check if any none-0 voxels exist
    [dummy, cv_file] = fileparts(curr_cv.fname);
    if any(intersect_vol(:))
        n_vox = sum(intersect_vol(:));
        display(sprintf('N=%i voxels overlap between %s and %s', n_vox, cv_file, roi_name))
        
        % save overlap in ROIAnalysis folder
        res_filename = fullfile(respath, sprintf('overlap_%s.nii', roi_name));
        
        display(sprintf('Saving result to %s', res_filename));
        res_hdr = curr_cv.hdr;
        res_hdr.fname = res_filename;
        res_hdr.descrip = sprintf('overlap_%s_%s', cv_file, roi_name);
        
        spm_write_vol(res_hdr, intersect_vol);
        
        header = sprintf('%s\\t%s\\t%s\\t%s\\t%s', 'cv_file', 'roi_file', 'n_vox_intersection', 'size_vox_AAL_total', 'size_vox_currcv_total');
        %                    result.(['withinReasonWithinContext_' roi_source]){end+1} = sprintf('%s\\t%s\\t%i\\t%i\\t%i\\t%i\\t%s', cv_file, roi_name, subject, n_vox, size_vox_AAL_total, size_vox_currcv_total, correction);
        
    else
        display(sprintf('No overlaps found between %s and %s', cv_file, roi_name))
    end
    
end
                

%% Create brainmaps per subject, per ROI using a Leave One Subject Out procedure
clear cfg
cfg.baseDir = baseDir;
cfg.dataDir = dataDir;
subdir = [dataDir, 'secondLevel/sameReasonSameContextSet3/'];
for subject = subsToDo
    
    for roi = roiNames
        
        % Leave current subject out
        subsForSecondLevel = [];
        for s = subsToDo
            if s ~= subject
                subsForSecondLevel(end+1) = s;
            end
        end
        
        
        % Get the appropriate images of all subjects but the current
        cfg.subsToDo    = subsForSecondLevel;
        cfg.filenames   = {};
        for sub = 1 : length(subsForSecondLevel)
            inputDir    = [baseDir, 'data/sub', num2str(subsForSecondLevel(sub), '%02i'),'/NIFTI/results/MVPA_allCombinationsSet3/'];
            cfg.filenames{end+1, 1} = [inputDir, 'averagesameReasonSameContext.nii'];
        end
        
        % Set the right output folder
        cfg.outputSubDir   = ['secondLevel/sameReasonSameContext/LOS', num2str(subject, '%02i'),'/'];
        if exist([dataDir, 'secondLevel/', cfg.outputSubDir])
            rmdir([dataDir, 'secondLevel/', cfg.outputSubDir], 's')
        end
        % Run the analysis
        secondLevelAnalysis (cfg);
        
        % threshold image
        clear cfg
        cfg.dataDir = dataDir;
        cfg.baseDir = baseDir;
        cfg.swd = [dataDir, 'secondLevel/sameReasonSameContext/LOS', num2str(subject, '%02i'),'/'];
        cfg.pm = .001;
        cfg.identstring = 'Classification'; % should be t-contrast with c = [1]
        [result, volumes] = get_SPM_FWEc_results(cfg);
        
        vol    = zeros(volumes.uncorr.xSPM.DIM(1:3)');
        Vind   = volumes.uncorr.xSPM.XYZ(1,:) + volumes.uncorr.xSPM.DIM(1)*(volumes.uncorr.xSPM.XYZ(2,:)-1 + volumes.uncorr.xSPM.DIM(2)*(volumes.uncorr.xSPM.XYZ(3,:)-1));
        vol(Vind)= volumes.uncorr.xSPM.Z.*(volumes.uncorr.xSPM.Z > 0);
        
        fname = fullfile([dataDir, 'secondLevel/sameReasonSameContext/LOS', num2str(subject, '%02i'),'/con_0001.nii']);
        hdr = spm_vol(fname);
        spm_write_vol(hdr, vol);

        
        % Use ROIs to restrict brain map  (Note, ROI is the overlap between
        % the anatomical rois and the decoding map from the SameSame
        % contition
        
        curr_roi = [];
        fname = fullfile(subdir, 'faROIs/', roi{1}, ['overlap_', roi{1}, '.nii']);
        hdr = spm_vol(fname);
        curr_roi = spm_read_vols(hdr);
        
        curr_cv = [];
        fname = fullfile(dataDir, 'secondLevel/', ['sameReasonSameContext/LOS', num2str(subject, '%02i'),'/'], 'con_0001.nii');
        hdr = spm_vol(fname);
        vol = (spm_read_vols(hdr));
        curr_cv.fname = fname;
        curr_cv.hdr = hdr;
        curr_cv.vol = (vol); % ~isnan(vol);
        
%         % Multiplying 2 3D matrices
%         
%         intersect_vol = zeros(curr_cv.hdr.dim);
%         for z = 1 : curr_cv.hdr.dim(3)
%            intersect_vol(:,:,z) = curr_roi(:,:,z) .* curr_cv.vol(:,:,z);
%         end
        
        intersect_vol = curr_roi & curr_cv.vol;
        size_vox_AAL_total = sum(curr_roi(:));
        size_vox_currcv_total = sum(curr_cv.vol(:));
        
        % check if any none-0 voxels exist
        [dummy, cv_file] = fileparts(curr_cv.fname);
        %if any(intersect_vol(:))
            n_vox = sum(intersect_vol(:));
            display(sprintf('N=%i voxels overlap between %s and %s', n_vox, cv_file, roi{1}))
            
            % save overlap
            filenameOverlap = fullfile(dataDir, 'secondLevel/sameReasonSameContext/faROIs', roi{1}, ['mask_sub', num2str(subject, '%02i'), '.nii']);
            mkdir(fullfile(dataDir, 'secondLevel/sameReasonSameContext/faROIs', roi{1}));
            display(sprintf('Saving result to %s', filenameOverlap));
            res_hdr = curr_cv.hdr;
            res_hdr.fname = filenameOverlap;
            res_hdr.descrip = sprintf('overlap_%s_%s', cv_file, roi{1});
            
            spm_write_vol(res_hdr, intersect_vol);
            
            header = sprintf('%s\\t%s\\t%s\\t%s\\t%s', 'cv_file', 'roi_file', 'n_vox_intersection', 'size_vox_AAL_total', 'size_vox_currcv_total');
            %                    result.(['withinReasonWithinContext_' roi_source]){end+1} = sprintf('%s\\t%s\\t%i\\t%i\\t%i\\t%i\\t%s', cv_file, roi_name, subject, n_vox, size_vox_AAL_total, size_vox_currcv_total, correction);
            
        %else
        %    display(sprintf('No overlaps found between %s and %s', cv_file, roi{1}))
        %end
    end
end
        
        

%% Extract decoding accuracy

clear cfg
cfg.baseDir = baseDir;
cfg.subsToDo = subsToDo;
cfg.resultsFolder = [dataDir, 'secondLevel/ROIAnalysis/'];
cfg.conditionNames  = conditionNames;
cfg.selectedROIs = roiNames;

extracted_CV_data = getDataFromLeftoutSecondlevels(cfg);

results.conditions = conditionNames;
results.subjects = length(subsToDo);
results.rois = roiNames;
results.conditions = conditionNames;
results.date = datetime;
for subject = 1 : length(subsToDo)
    for roi = 1 : length(roiNames)
        for conditionind = 1 : 4
            condition_name = conditionNames{conditionind}; 
            results.classification(subject, conditionind, roi) = extracted_CV_data.(roiNames{roi}).uncorr.p001.sub{1, subject}.(condition_name).mean;
        end
    end
end

%% Final statistics

%% plot averages across subjects

clear set;

[nsbj, ncond, nrois] = size(results.classification);

titlestr = 'Plot condition across subjects for each ROI';
try
    figure(fig_cond)
catch
    fig_cond = figure('name', titlestr, 'Position', [22          93         663        1018]);
end
nplots = nrois;
sp_x = ceil(nplots/4);
sp_y = ceil(nplots/sp_x);
 
colors =    [0, 0.68, 1
             0.17, 0.71, 0.5
             1, 0, 0.6
             1, 0.69, 0.25];
pvalues = zeros(4,4);        
for roi_ind = 1:nrois
    [H, ps] = ttest(results.classification(:, :, roi_ind), 0, 'Tail','right', 'alpha', 0.0031); % ttset: DA>0? onesided

    curr_cond_mean = nanmean(results.classification(:, :, roi_ind));
    curr_cond_mean = curr_cond_mean + 50;
    curr_cond_std = std(results.classification(:, :, roi_ind));
     
    n_nans = sum(~isnan(results.classification(:, :, roi_ind)));
    subplot(sp_x, sp_y, roi_ind);
    %bar(curr_cond_mean);
    hold on
    for condition = 1 : 4
        bar([condition], curr_cond_mean(condition), 'FaceColor', colors(condition,:));
    end
    set(gca,'xtick', 1:4);% 'xticklabel',conditionNames);
    set(gca, 'ylim', [0, 65]);
    set(gca, 'xlim', [0, 5]);
    %xlabel(['n=' sprintf('%i ', n_nans)]);
    title(roiNames{roi_ind});
     
    % add CI
    hold on
    %curr_CI = sqrt(curr_cond_var)./sqrt(n_nans) * 1.96; % CI95 = SEM * 1.96
    errorbar(curr_cond_mean , curr_cond_std/sqrt(subjects), '.');
    
    % add chance level
    plot(get(gca, 'xlim'), [50, 50], '--', 'color', 'k', 'LineWidth', 1.2)

    % add star
    for p_ind = 1:length(ps)
        thresh = .003125/length(ps);
        if ps(p_ind) < thresh
            text(p_ind, 62, '*', 'FontSize', 14)
        end
    end
    pvalues(roi_ind,:) = ps;
end

%%%% Final statistics

%% plot averages across subjects II (No Bars)

clear set;

[nsbj, ncond, nrois] = size(results.classification);

titlestr = 'Plot condition across subjects for each ROI';
try
    figure(fig_cond)
catch
    fig_cond = figure('name', titlestr, 'Position', [22          93         1280        400]);
end
nplots = nrois;
sp_x = ceil(nplots/4);
sp_y = ceil(nplots/sp_x);
 
colors =    [0, 0.68, 1
             0.17, 0.71, 0.5
             1, 0, 0.6
             1, 0.69, 0.25];
pvalues = zeros(4,4);        
for roi_ind = 1:nrois
    %[H, ps] = ttest(results.classification(:, :, roi_ind), 0, 'Tail','right', 'alpha', 0.0031); % ttset: DA>0? onesided
    [H, ps, CI] = ttest(results.classification(:, :, roi_ind), 0, 'Tail', 'right', 'alpha', 0.05/16); % ttset: DA>0? onesided

    curr_cond_mean = nanmean(results.classification(:, :, roi_ind));
    curr_cond_mean = curr_cond_mean + 50;
    curr_cond_std = std(results.classification(:, :, roi_ind));
     
    n_nans = sum(~isnan(results.classification(:, :, roi_ind)));
    subplot(sp_x, sp_y, roi_ind);
    %bar(curr_cond_mean);
    hold on
    for condition = 1 : 4
        plot([condition], curr_cond_mean(condition), 'diamond', 'MarkerSize', 20, 'Color', colors(condition,:), 'markerfacecolor',colors(condition,:));
    end
    set(gca,'xtick', 1:4);% 'xticklabel',conditionNames);
    set(gca, 'ylim', [46, 62]);
    set(gca, 'xlim', [0, 5]);
    %xlabel(['n=' sprintf('%i ', n_nans)]);
    title(roiNames{roi_ind});
     
    % add CI
    hold on
    %curr_CI = sqrt(curr_cond_var)./sqrt(n_nans) * 1.96; % CI95 = SEM * 1.96
    errorbar(curr_cond_mean , curr_cond_std/sqrt(nsbj) * 2.9552, '.', 'LineWidth', 1.5, 'Color', 'black');
    %errorbar(curr_cond_mean , curr_cond_std/sqrt(subjects)*4, '.', 'LineWidth', 1.5, 'Color', 'black');

    % add chance level
    plot(get(gca, 'xlim'), [50, 50], '--', 'color', 'k', 'LineWidth', 1.5)

    % add star
    for p_ind = 1:length(ps)
        thresh = .003125/length(ps);
        if ps(p_ind) < 0.001/(ncond*nrois)
            text(p_ind-0.24, 61, '****', 'FontSize', 18)
        elseif ps(p_ind) < 0.005/(ncond*nrois)
            text(p_ind-0.16, 61, '***', 'FontSize', 18)
        elseif ps(p_ind) < 0.01/(ncond*nrois)
            text(p_ind-0.08, 61, '**', 'FontSize', 18)
        elseif ps(p_ind) < 0.05/(ncond*nrois)
            text(p_ind, 61, '*', 'FontSize', 18)
        end
    end
    pvalues(roi_ind,:) = ps;
end

%%

[nsbj, ncond, nrois] = size(results.classification);

% ttest against 0
  
titlestr = 'ttest each condition across subjects for each ROI';
try
    figure(fig_cond_ttest)
catch
    fig_cond_ttest = figure('name', titlestr, 'Position', [22          93         663        1018]);
end
nplots = nrois;
sp_x = ceil(nplots/4);
sp_y = ceil(nplots/sp_x);
 
 
for roi_ind = 1:nrois
    [H, p] = ttest(results.classification(:, :, roi_ind), 0, 'Tail','right', 'alpha', 0.01667); % ttset: DA>0? onesided

    all_Hs(:, roi_ind) = H;
     
    n_nans = sum(~isnan(results.classification(:, :, roi_ind)));
    subplot(sp_x, sp_y, roi_ind);
    bar(1-p); % plot p-values of ttest
    hold on
    bar(find(H==1), 1-p(H==1), 'r'); % significant bars red
    plot(get(gca, 'xlim'), 1-[.017 .01667], 'color', 'k') % p=5% line
     
    %xlabel(['n=' sprintf('%i ', n_nans)]);
    title(roiNames(roi_ind));
     
    if roi_ind == 1
        ylabel('1-p (one-sided ttest)')
    end
    
end



%% Create Table for JASP


for roi = 1 : length(roiNames)
    resultsForJasp = results.classification(:,:, roi);
    filename = [roiNames{roi}, '.csv'];
    f = fopen(filename, 'w') ;
    fprintf(f, '%s, %s, %s, %s\n', conditionNames{:}) ;
    dlmwrite(filename, resultsForJasp, '-append') ;
end;

