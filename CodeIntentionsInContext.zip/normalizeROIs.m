function normalizeROIs (baseDir, subject)


%% Set paths
subDir = [baseDir, 'data/sub', num2str(subject, '%02i'), '/NIFTI/'];
ROIDir = [subDir, '/ROIs/'];
structDir = [subDir, 'T1'];
matlabbatch{1}.spm.spatial.normalise.write.subj.def(1) = cellstr(spm_select('FPList', structDir, '^y_.*\.nii$'));
matlabbatch{1}.spm.spatial.normalise.write.subj.resample =  cellstr(spm_select('FPList', ROIDir, '^native.*\.nii$'));
matlabbatch{1}.spm.spatial.normalise.write.woptions.bb = [-78 -112 -70; 78 76 85];
matlabbatch{1}.spm.spatial.normalise.write.woptions.vox = [2 2 2];
matlabbatch{1}.spm.spatial.normalise.write.woptions.interp = 7;

spm_jobman('run',matlabbatch);
