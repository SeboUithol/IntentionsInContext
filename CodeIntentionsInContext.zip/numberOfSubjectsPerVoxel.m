% Produces Image with all per voxel number of subjects that show a
% significant DA in "Same" condition

% Create cluster not according to the leave-one-subject-out scheme, but
% plainly for indivudual subjects.

% First, obtain the average DA of all sets for each subject

cfg.baseDir = baseDir;

for subject = subsToDo
    

    cfg.filenames   = {};
    inputDir    = [baseDir, 'data/sub', num2str(subject, '%02i'),'/NIFTI/results/MVPA_allCombinations/'];
    for set = 1 : length(same)
        cfg.filenames{end+1, 1} = {[inputDir, 'swres_accuracy_minus_chance_set00', num2str(same(set), '%02i'),'.nii']};
    end
    
    
    % Set the right output folder
    cfg.outputDir   = ['sameReasonSameContext/subject', num2str(subject, '%02i'),'/'];
    % Run the analysis
    secondLevelAnalysis (cfg);
    
end

for subject = 1 : length(subsToDo)
    cfg.swd = [baseDir, 'secondLevel/sameReasonSameContext/subject', num2str(subsToDo(subject), '%02i'),'/'];
    cfg.pm = .001;
    cfg.identstring = 'Classification'; % should be t-contrast with c = [1]
    cfg.filestart = 'binary_';
    
    write.second_level_uncorr = 1;
    write.second_level_FWEc05 = 1;
    [result, volumes] = get_SPM_FWEc_results(cfg, write);
end




% Load first cluster
fileName = [baseDir, 'secondLevel/sameReasonSameContext/subject', num2str(subsToDo(1), '%02i'),'/binary__p0.0010_uncorr.nii'];
hdr = spm_vol(fileName);
allClusters = zeros(hdr.dim); %spm_read_vols(hdr);

% Add remaining Clusters

for subject = 1 : length(subsToDo)
    fileName = [baseDir, 'secondLevel/sameReasonSameContext/subject', num2str(subsToDo(subject), '%02i'),'/binary__p0.0010_uncorr.nii'];
    hdr = spm_vol(fileName);
    vol = spm_read_vols(hdr);
    vol(isfinite(vol))=1;
    vol(~isfinite(vol))=0;
    allClusters = allClusters + vol;
end

% save cluster
clusterDir = [baseDir, 'secondLevel/sameReasonSameContext/'];
fileName = 'mapNumberSubjects.nii';
display(['Saving result to ', clusterDir, fileName]);
res_hdr = hdr;
res_hdr.fname = [clusterDir, fileName];

% Overlay mask

    hdr = spm_vol([baseDir, 'secondLevel/sameReasonSameContext/subject', num2str(subsToDo(subject), '%02i'),'/binary__p0.0010_uncorr.nii'];);
    vol = spm_read_vols(hdr);

spm_write_vol(res_hdr, allClusters);