function baseDir = getBaseDir

% get name of computer
[s, hostname] = system('hostname');
hostname = strtrim(hostname);

% return basedir for this computer (including dataAnalysis at the end)
switch hostname
    case 'WHISPER'
        baseDir = 'C:\Users\kai\Dropbox\IntentionsInContext\dataAnalysis';
    case 'Sebos-MacBook-Pro.local'
        baseDir = '/Users/SeboUithol/Documents/BCAN/intentionsContext/';
    case 'mac-sebuit.dccn.nl'
        baseDir = '/Users/SeboUithol/Documents/BCAN/intentionsContext/';
    case 'ip-145-116-133-37.wlan-int.ru.nl'
        baseDir = '/Users/SeboUithol/Documents/BCAN/intentionsContext/'; 
    case 'sebos-mbp.home'
        baseDir = '/Users/SeboUithol/Documents/BCAN/intentionsContext/'; 
    otherwise
        error('please add your hostname %s here.', hostname)
end

