function preprocess(baseDir, subject)


nrun = 5; % number of runs
% runn defines which steps we want to do
% 1 = Build VDM file
% 2 = Realign and Unwarp 
% 3 = Slice timing (write)
% 4 = Coregistration 
% 5 = Segmentation 
% 6 = Normalization
% 7 = Smoothing   (write)

processSteps = ones(1,7);

subDir = [baseDir, 'data/sub', num2str(subject, '%02i'), '/NIFTI/'];
structDir = [subDir, '/T1'];
fieldMagDir = [subDir, '/FieldmapMag/'];
fieldPhaseDir = [subDir, '/FieldmapPhase/'];
roiNMIDir = [baseDir, '/ROIsNMI/'];
roiSubjectDir = [subDir, 'ROIs/'];
spmDir = '/Users/SeboUithol/Matlab/SPM12/';

for runNumber = 1:nrun
    runDir{runNumber} = [subDir, sprintf('run%01i/', runNumber)]; 
end


%% change to log directory (to save ps files there)
logdir = fullfile(baseDir, 'log');
mkdir(logdir)
cd(logdir)

%% start spm fmri

batn=0; % init matlabbatch counter
spm_jobman('initcfg'); % initialise SPM batch mode

%% build vdm file
if processSteps(1)==1; 
    clear matlabbatch; 
    batn=0; 
end;
batn=batn+1;

matlabbatch{batn}.spm.tools.fieldmap.presubphasemag.subj.phase = cellstr(spm_select('FPList', fieldPhaseDir, '.*2.nii$'));
matlabbatch{batn}.spm.tools.fieldmap.presubphasemag.subj.magnitude = cellstr(spm_select('FPList', fieldMagDir, '.*2.nii$'));
matlabbatch{batn}.spm.tools.fieldmap.presubphasemag.subj.defaults.defaultsval.et = [5.19 7.65];
matlabbatch{batn}.spm.tools.fieldmap.presubphasemag.subj.defaults.defaultsval.maskbrain = 1;
matlabbatch{batn}.spm.tools.fieldmap.presubphasemag.subj.defaults.defaultsval.blipdir = -1;
matlabbatch{batn}.spm.tools.fieldmap.presubphasemag.subj.defaults.defaultsval.tert = 32.64; % How was it calculated?
matlabbatch{batn}.spm.tools.fieldmap.presubphasemag.subj.defaults.defaultsval.epifm = 0; % Non-EPI?
matlabbatch{batn}.spm.tools.fieldmap.presubphasemag.subj.defaults.defaultsval.ajm = 0; 
matlabbatch{batn}.spm.tools.fieldmap.presubphasemag.subj.defaults.defaultsval.uflags.method = 'Mark3D';
matlabbatch{batn}.spm.tools.fieldmap.presubphasemag.subj.defaults.defaultsval.uflags.fwhm = 10; % why 10?
matlabbatch{batn}.spm.tools.fieldmap.presubphasemag.subj.defaults.defaultsval.uflags.pad = 0;
matlabbatch{batn}.spm.tools.fieldmap.presubphasemag.subj.defaults.defaultsval.uflags.ws = 1;
matlabbatch{batn}.spm.tools.fieldmap.presubphasemag.subj.defaults.defaultsval.mflags.template = {[spmDir 'toolbox/FieldMap/T1.nii']};
matlabbatch{batn}.spm.tools.fieldmap.presubphasemag.subj.defaults.defaultsval.mflags.fwhm = 5;
matlabbatch{batn}.spm.tools.fieldmap.presubphasemag.subj.defaults.defaultsval.mflags.nerode = 2;
matlabbatch{batn}.spm.tools.fieldmap.presubphasemag.subj.defaults.defaultsval.mflags.ndilate = 4;
matlabbatch{batn}.spm.tools.fieldmap.presubphasemag.subj.defaults.defaultsval.mflags.thresh = 0.5;
matlabbatch{batn}.spm.tools.fieldmap.presubphasemag.subj.defaults.defaultsval.mflags.reg = 0.02;

%EPIs
for run = 1:nrun
    epi_list = cellstr(spm_select('FPList', runDir{run}, '^f.*\.nii$'));
    matlabbatch{batn}.spm.tools.fieldmap.presubphasemag.subj.session(run).epi = epi_list;
    clear epi_list;
end;

matlabbatch{batn}.spm.tools.fieldmap.presubphasemag.subj.matchvdm = 1;
matlabbatch{batn}.spm.tools.fieldmap.presubphasemag.subj.sessname = 'session';
matlabbatch{batn}.spm.tools.fieldmap.presubphasemag.subj.writeunwarped = 1;
matlabbatch{batn}.spm.tools.fieldmap.presubphasemag.subj.anat = cellstr(spm_select('FPList', structDir, '^s.*.nii$'));
matlabbatch{batn}.spm.tools.fieldmap.presubphasemag.subj.matchanat = 1;
%%
if processSteps(1)==1;
    spm_jobman('run',matlabbatch);
end;

%% realign and unwarp

if processSteps(2)==1; 
    clear matlabbatch; 
    batn=0; 
end;
batn=batn+1;

for run = 1:nrun
    matlabbatch{batn}.spm.spatial.realignunwarp.data(run).scans = cellstr(spm_select('FPList', runDir{run}, '^f.*.nii$')) ;
    matlabbatch{batn}.spm.spatial.realignunwarp.data(run).pmscan = cellstr(spm_select('FPList', fieldPhaseDir, sprintf('%s%.1d%s','^vdm5_scfpm.*session',run,'.nii')));
end;

matlabbatch{batn}.spm.spatial.realignunwarp.eoptions.quality = 1;
matlabbatch{batn}.spm.spatial.realignunwarp.eoptions.sep = 4;
matlabbatch{batn}.spm.spatial.realignunwarp.eoptions.fwhm = 5;
matlabbatch{batn}.spm.spatial.realignunwarp.eoptions.rtm = 1;
matlabbatch{batn}.spm.spatial.realignunwarp.eoptions.einterp = 7;
matlabbatch{batn}.spm.spatial.realignunwarp.eoptions.ewrap = [0 0 0];
matlabbatch{batn}.spm.spatial.realignunwarp.eoptions.weight = '';
matlabbatch{batn}.spm.spatial.realignunwarp.uweoptions.basfcn = [12 12];
matlabbatch{batn}.spm.spatial.realignunwarp.uweoptions.regorder = 1;
matlabbatch{batn}.spm.spatial.realignunwarp.uweoptions.lambda = 100000;
matlabbatch{batn}.spm.spatial.realignunwarp.uweoptions.jm = 0;
matlabbatch{batn}.spm.spatial.realignunwarp.uweoptions.fot = [4 5];
matlabbatch{batn}.spm.spatial.realignunwarp.uweoptions.sot = [];
matlabbatch{batn}.spm.spatial.realignunwarp.uweoptions.uwfwhm = 4;
matlabbatch{batn}.spm.spatial.realignunwarp.uweoptions.rem = 1;
matlabbatch{batn}.spm.spatial.realignunwarp.uweoptions.noi = 5;
matlabbatch{batn}.spm.spatial.realignunwarp.uweoptions.expround = 'Average';
matlabbatch{batn}.spm.spatial.realignunwarp.uwroptions.uwwhich = [2 1];
matlabbatch{batn}.spm.spatial.realignunwarp.uwroptions.rinterp = 7;
matlabbatch{batn}.spm.spatial.realignunwarp.uwroptions.wrap = [0 0 0];
matlabbatch{batn}.spm.spatial.realignunwarp.uwroptions.mask = 1;
matlabbatch{batn}.spm.spatial.realignunwarp.uwroptions.prefix = 'u';

if processSteps(2)==1;
    spm_jobman('run',matlabbatch);
end;

%% slice timing

if processSteps(3)==1; 
    clear matlabbatch; 
    batn=0; 
end;
batn=batn+1;

for i = 1:nrun
    matlabbatch{batn}.spm.temporal.st.scans{1,i} = cellstr(spm_select('FPList', runDir{i}, '^uf.*\.nii$'));
end;

tr = 2;
nslices = 33;
matlabbatch{batn}.spm.temporal.st.nslices = nslices;
matlabbatch{batn}.spm.temporal.st.tr = tr;
matlabbatch{batn}.spm.temporal.st.ta = tr - tr/nslices; % TE = TR - TR/nslices
matlabbatch{batn}.spm.temporal.st.so = nslices:-1:1; % descending order
matlabbatch{batn}.spm.temporal.st.refslice = 16;
matlabbatch{batn}.spm.temporal.st.prefix = 'a';

if processSteps(3)==1;
    spm_jobman('run',matlabbatch);
end;

%% coregistration

if processSteps(4)==1; 
    clear matlabbatch; 
    batn=0; 
end;
batn=batn+1;

matlabbatch{batn}.spm.spatial.coreg.estimate.ref(1) = cellstr(spm_select('FPList', runDir{1}, '^meanuf.*\.nii$')); % Why meanuf not meanauf?
matlabbatch{batn}.spm.spatial.coreg.estimate.source = cellstr(spm_select('FPList', structDir, '^s.*.nii$'));
matlabbatch{batn}.spm.spatial.coreg.estimate.other = {''};
matlabbatch{batn}.spm.spatial.coreg.estimate.eoptions.cost_fun = 'nmi';
matlabbatch{batn}.spm.spatial.coreg.estimate.eoptions.sep = [4 2];
matlabbatch{batn}.spm.spatial.coreg.estimate.eoptions.tol = [0.02 0.02 0.02 0.001 0.001 0.001 0.01 0.01 0.01 0.001 0.001 0.001];
matlabbatch{batn}.spm.spatial.coreg.estimate.eoptions.fwhm = [7 7];

if processSteps(4)==1;
    spm_jobman('run',matlabbatch);
end;

%% segmentation

if processSteps(5)==1; 
    clear matlabbatch; 
    batn=0; 
end;
batn=batn+1;

matlabbatch{batn}.spm.spatial.preproc.channel.vols = cellstr(spm_select('FPList', structDir, '^s.*.nii$'));
matlabbatch{batn}.spm.spatial.preproc.channel.biasreg = 0.001;
matlabbatch{batn}.spm.spatial.preproc.channel.biasfwhm = 60;
matlabbatch{batn}.spm.spatial.preproc.channel.write = [0 1];
matlabbatch{batn}.spm.spatial.preproc.tissue(1).tpm =  {[spmDir 'tpm/TPM.nii,1']};
matlabbatch{batn}.spm.spatial.preproc.tissue(1).ngaus = 1;
matlabbatch{batn}.spm.spatial.preproc.tissue(1).native = [1 0];
matlabbatch{batn}.spm.spatial.preproc.tissue(1).warped = [0 0];
matlabbatch{batn}.spm.spatial.preproc.tissue(2).tpm = {[spmDir 'tpm/TPM.nii,2']};
matlabbatch{batn}.spm.spatial.preproc.tissue(2).ngaus = 1;
matlabbatch{batn}.spm.spatial.preproc.tissue(2).native = [1 0];
matlabbatch{batn}.spm.spatial.preproc.tissue(2).warped = [0 0];
matlabbatch{batn}.spm.spatial.preproc.tissue(3).tpm = {[spmDir 'tpm/TPM.nii,3']};
matlabbatch{batn}.spm.spatial.preproc.tissue(3).ngaus = 2;
matlabbatch{batn}.spm.spatial.preproc.tissue(3).native = [1 0];
matlabbatch{batn}.spm.spatial.preproc.tissue(3).warped = [0 0];
matlabbatch{batn}.spm.spatial.preproc.tissue(4).tpm = {[spmDir 'tpm/TPM.nii,4']};
matlabbatch{batn}.spm.spatial.preproc.tissue(4).ngaus = 3;
matlabbatch{batn}.spm.spatial.preproc.tissue(4).native = [1 0];
matlabbatch{batn}.spm.spatial.preproc.tissue(4).warped = [0 0];
matlabbatch{batn}.spm.spatial.preproc.tissue(5).tpm = {[spmDir 'tpm/TPM.nii,5']};
matlabbatch{batn}.spm.spatial.preproc.tissue(5).ngaus = 4;
matlabbatch{batn}.spm.spatial.preproc.tissue(5).native = [1 0];
matlabbatch{batn}.spm.spatial.preproc.tissue(5).warped = [0 0];
matlabbatch{batn}.spm.spatial.preproc.tissue(6).tpm = {[spmDir 'tpm/TPM.nii,6']};
matlabbatch{batn}.spm.spatial.preproc.tissue(6).ngaus = 2;
matlabbatch{batn}.spm.spatial.preproc.tissue(6).native = [0 0];
matlabbatch{batn}.spm.spatial.preproc.tissue(6).warped = [0 0];
matlabbatch{batn}.spm.spatial.preproc.warp.mrf = 1;
matlabbatch{batn}.spm.spatial.preproc.warp.cleanup = 1;
matlabbatch{batn}.spm.spatial.preproc.warp.reg = [0 0.001 0.5 0.05 0.2];
matlabbatch{batn}.spm.spatial.preproc.warp.affreg = 'mni';
matlabbatch{batn}.spm.spatial.preproc.warp.fwhm = 0;
matlabbatch{batn}.spm.spatial.preproc.warp.samp = 3;
matlabbatch{batn}.spm.spatial.preproc.warp.write = [1 1];

if processSteps(5)==1;
    spm_jobman('run',matlabbatch);
end;


%% normalise (write)

if processSteps(6)==1; 
    clear matlabbatch; 
    batn=0; 
end;
batn=batn+1;

matlabbatch{batn}.spm.spatial.normalise.write.subj.def(1) = cellstr(spm_select('FPList', structDir, '^y_.*\.nii$'));

files={};
for i =1:nrun
    file{1} = cellstr(spm_select('FPList', runDir{i}, '^auf.*\.nii$'));
    files=[files;file{1}];
end;
%files = [files; cellstr(spm_select('FPList', runDir{1}, '^meanuf.*\.nii$'))];
files = [files; cellstr(spm_select('FPList', structDir, '^sBCCN.*\.nii$'))];
matlabbatch{batn}.spm.spatial.normalise.write.subj.resample = files;

matlabbatch{batn}.spm.spatial.normalise.write.woptions.bb = [-78 -112 -70; 78 76 85];
matlabbatch{batn}.spm.spatial.normalise.write.woptions.vox = [2 2 2];
matlabbatch{batn}.spm.spatial.normalise.write.woptions.interp = 7;

if processSteps(6)==1;
    spm_jobman('run',matlabbatch);
end;

%% smooth

if processSteps(7)==1; 
    clear matlabbatch; 
    batn=0; 
end;
batn=batn+1;

for i = 1:nrun
    matlabbatch{batn}.spm.spatial.smooth.data = cellstr(spm_select('FPList', runDir{i}, '^wauf.*\.nii$'));
    matlabbatch{batn}.spm.spatial.smooth.fwhm = [6 6 6];
    matlabbatch{batn}.spm.spatial.smooth.dtype = 0;
    matlabbatch{batn}.spm.spatial.smooth.im = 0;
    matlabbatch{batn}.spm.spatial.smooth.prefix = 's';
    batn=batn+1;
end;

if processSteps(7)==1;
     spm_jobman('run',matlabbatch);
end;

disp('Batch finished')

cd (baseDir)
