% function [result, volumes] = get_SPM_FWEc_results(cfg, write)
%
% Function to get cluster (and optional write) significant results and
% significant cluster results from a SPM mat.
%
% The contrast can be either specified as contrast index or contrast name 
% (see cfg.contrast_index and cfg.identstring below). Passing the index
% saves loading the SPM.mat. As additional precaution, you can pass 
% cfg.identstring to check if identstring is contained in the loaded 
% contrast.
%
% Note: The bottom of this explanation explains how a volume can be 
% reconstructed from the output of this function.
%
% IN
% cfg: Struct containing the following fields
%   cfg.swd: Directory containing SPM.mat, e.g. '/data/path'
%   cfg.pm: Individual voxel threshold
%	cfg.contrast_index: Index of contrast to extract (e.g. 2 for second
%           contrast). If the contrast index is not provided (or empty) it
%           will be retrieved from the SPM.mat using cfg.identstring below.
%   cfg.identstring: string that should be included somewhere of the loaded
%       contrast. If cfg.contrast_index is provided, it will be checked
%       that cfg.identstring is part of the contrast name. Otherwise, the
%       SPM.mat will be loaded and FIRST the exact string will be searched
%       in the contrast names. If no exact match is found, a contrast
%       that contains identstring will be looked for (and it will only work
%       if the result is exactly 1 contrast).
%   optional field for cfg
%       cfg.title_start: String for begin of title (p values etc. will be added
%           after this)
%   cfg.filestart: String at the beginning of each file
%
% write: Specifying what to write. 
%   write.dir: Directory where to write the output (optional, default: cfg.swd)
%   write.second_level_uncorr = 0|1: write uncorrected significant
%           outcome to file
%   write.second_level_FWEc05 = 0|1: write FWEc p<0.05 significant
%           outcome to file
%
% OUT
%   result: struct with simple statistics
%         result.pm:       Single voxel threshold (from cfg.pm);
%         result.t_thresh: t-value for given single voxel p
%         result.k:        k for FWEc correction
%         result.filename_uncorr: Filename of FWEc05 written file or 'uncorrNOTWRITTEN'
%         result.filename_FWEc05: Filename of FWEc05 written file or 'FWEc05NOTWRITTEN'
%       
%   volumes: all information
%       volumes.uncorr.xSPM: has parameters and outcomes for uncorr
%       volumes.FWEc05.xSPM: has parameters and outcomes for FWEc05
%
% EXAMPLE CALL
%    cfg.swd = secondLevelDir;
%    cfg.pm = .001;
%    cfg.identstring = 'Classification'; % contrast must exists
%           % check SPM batch functionality how to create a contrast
%    [result, volumes] = get_SPM_FWEc_results(cfg);
% 
%
% Use
% %-Reconstruct (filtered) image from XYZ & Z pointlist
% %--------------------------------------------------------------------------
% vol    = zeros(xSPM.DIM(1:3)');
% Vind   = xSPM.XYZ(1,:) + xSPM.DIM(1)*(xSPM.XYZ(2,:)-1 + xSPM.DIM(2)*(xSPM.XYZ(3,:)-1));
% vol(Vind)= xSPM.Z.*(xSPM.Z > 0);
%
% To get the volume back (or Vind as indices were volmeinformation is)
%
% Kai, 2015/04/23

function [result, volumes] = get_SPM_FWEc_results(cfg, write)

%% Extract cfg and optional cfg input

pm = cfg.pm;

if ~isfield(cfg, 'title_start')
    % take name of last folder and contrast
    [dummy, swd_part] = fileparts(cfg.swd);
    if isfield(cfg, 'contrast_index')
        cfg.title_start = [swd_part, 'Contrast ' num2str(cfg.contrast_index)]
    elseif isfield(cfg, 'identstring')
        cfg.title_start = [swd_part, 'Contrast ' num2str(cfg.identstring)]
    end
end

if ~exist('write', 'var') % write nothing
    write.second_level_uncorr = 0;
    write.second_level_FWEc05 = 0;
end
if ~isfield(write, 'dir')
    write.dir = cfg.swd; % use directory of SPM.mat
end


%% get index of contrast if it is not provided
if ~isfield(cfg, 'contrast_index') && isfield(cfg, 'identstring')
    display(sprintf('Retrieving contrast index for identstring %s from SPM.mat in %s', cfg.identstring, cfg.swd))
    curr_SPM = load(fullfile(cfg.swd, 'SPM.mat'));
    % try to find exact match first
    contrast_names = {curr_SPM.SPM.xCon(:).name};
    cfg.contrast_index = find(strcmp(contrast_names, cfg.identstring)); % Index of contrast to extract (e.g. 2 for second contrast)
    if length(cfg.contrast_index) ~= 1
        % try if identstring is part of any contrast name
        if isempty(cfg.contrast_index)
            display('No contrast exactly matched the string, trying to find contrast name part')
            cfg.contrast_index = [];
            for con_ind = 1:length(contrast_names)
                if ~isempty(findstr(cfg.identstring, contrast_names{con_ind}));
                    display(sprintf('Contrast %i: %s matched identstring (%s)', con_ind, contrast_names{con_ind}, cfg.identstring))
                    cfg.contrast_index(end+1) = con_ind;
                end
            end
        end
        % abort if not exactly 1 was found
        if length(cfg.contrast_index) ~= 1
            error('Could not uniquely identify contrast index. Expected to find 1 contrast named %s, but found %i. Please make sure the name is unique', cfg.identstring, length(cfg.contrast_index))
        end
    end
end

%% specify spm 2nd level analysis
xSPM = []; % - structure containing SPM, distribution & filtering details

% directory to LEFT OUT SUBJECT 2nd level analysis
% ADAPT HERE
xSPM.swd = cfg.swd; % SPM working directory - directory containing current SPM.mat

xSPM.title = sprintf('%s p<%.4f, uncorr.', cfg.title_start, pm); %   - title for comparison (string)
% .Z        - minimum of Statistics {filtered on u and k}
% .n        - conjunction number <= number of contrasts
% .STAT     - distribution {Z, T, X, F or P}
% .df       - degrees of freedom [df{interest}, df{residual}]
% .STATstr  - description string

% IMPORTANT! set contrast index here
xSPM.Ic = cfg.contrast_index; %       - indices of contrasts (in SPM.xCon)

xSPM.Im = []; % no masking       - indices of masking contrasts (in xCon)
% xSPM.pm = pm; %      - p-value for masking (uncorrected)
%           .Ex = 1;      - flag for exclusive or inclusive masking
%               (ALREADY done during 2nd level estimation, thus we dont
%                need to set a mask here)
xSPM.u = pm; %        - height threshold
xSPM.k = 1; % we start uncorrected, getting the threshold for FWEc by the first calculation       - extent threshold {voxels}
% .XYZ      - location of voxels {voxel coords}
% .XYZmm    - location of voxels {mm}
% .S        - search Volume {voxels}
% .R        - search Volume {resels}
% .FWHM     - smoothness {voxels}
% .M        - voxels -> mm matrix
% .iM       - mm -> voxels matrix
% .VOX      - voxel dimensions {mm} - column vector
% .DIM      - image dimensions {voxels} - column vector
% .Vspm     - Mapped statistic image(s)
% .Ps       - uncorrected P values in searched volume (for voxel FDR)
% .Pp       - uncorrected P values of peaks (for peak FDR)
% .Pc       - uncorrected P values of cluster extents (for cluster FDR)
% .uc       - 0.05 critical thresholds for FWEp, FDRp, FWEc, FDRc
xSPM.thresDesc = 'none'; % no control - description of height threshold (string)

%% do it

% REMARK: returns FWEc in xSPM.uc(3)

display(['Getting uncorrected significant results to retrieve k for FWEc from ' xSPM.swd])

% do it once to get the k for FWEc
[SPM,uncorr_xSPM] = spm_getSPM(xSPM);

if isfield(cfg, 'identstring')
    % check if the loaded contrast has the right name
    if isempty(findstr(cfg.identstring, uncorr_xSPM.Vspm.descrip))
        error('The file description of the loaded contrast %i (%s) does not fit to cfg.identstring (%s), please check')
    end
end

% save uncorrected result
if write.second_level_uncorr
    filename_uncorr = sprintf('%s_p%.4f_uncorr', cfg.filestart, pm);
    fullf = [write.dir, filename_uncorr, '.nii'];
    spm_write_filtered(uncorr_xSPM.Z,uncorr_xSPM.XYZ,uncorr_xSPM.DIM,uncorr_xSPM.M, ...
        sprintf('SPM{%c}-filtered: u = %5.3f, uncorr', ...
        uncorr_xSPM.STAT,uncorr_xSPM.u), fullf);
else
    display('Skip writing uncorrected removed 2ndlevel images')
end
volumes.uncorr.xSPM = uncorr_xSPM;

%         warning('Skipping FWEc and cluster extraction, remove this line if not wanted')
%         continue

%% continue with FWEc
% extract k from result
k = uncorr_xSPM.uc(3);
display(['Getting FWEc corrected results with k=' num2str(k) ' from ' xSPM.swd])

% change xSPM so that this time FWEc .05 is computed
xSPM.k = k;
xSPM.title = sprintf('%s p<%.4f, FWEc, k=%i', cfg.title_start, pm, xSPM.k); %   - title for comparison (string)
[SPM,xSPM] = spm_getSPM(xSPM);

% save full image (no clusters yet)
if write.second_level_FWEc05
    filename_FWEc05 = sprintf('%s_p%.4f_FWEc05_k%i', cfg.filestart, pm, xSPM.k);
    fullf = [write.dir, filename_FWEc05, '.nii'];
    spm_write_filtered(xSPM.Z,xSPM.XYZ,xSPM.DIM,xSPM.M, ...
        sprintf('SPM{%c}-filtered: u = %5.3f, k = %d', ...
        xSPM.STAT,xSPM.u,xSPM.k), fullf);
else

    display('Skip writing removed 2ndlevel images')
end

volumes.FWEc05.xSPM = xSPM;

% save parameters to return (only k is new, and name of files (if written)
result.pm = pm;
result.k = k;
result.t_thresh = uncorr_xSPM.u;

if exist('filename_uncorr', 'var')
    result.filename_uncorr = filename_uncorr;
else
    result.filename_uncorr = 'uncorrNOTWRITTEN';
end

if exist('filename_FWEc05', 'var')
    result.filename_FWEc05 = filename_FWEc05;
else
    result.filename_FWEc05 = 'FWEc05NOTWRITTEN';
end