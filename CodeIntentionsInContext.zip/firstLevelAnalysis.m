function firstLevelAnalysis(subject, cfg) % Input subject number and the type of images that is needef for model building

subDir = [cfg.baseDir, 'data/sub', num2str(subject, '%02i'), '/NIFTI/'];
structDir = [subDir, 'T1'];
outputDir = [subDir, 'results/', cfg.outputDir];
mkdir (outputDir)
spmDir = sprintf('/Users/SeboUithol/Matlab/SPM12/');

%% Add paths 
addpath(genpath('/Users/SeboUithol/Documents/BCAN/analysis/')) % Add analysis


%% Import PsychoPy log and Create Onset Matrix

filename = sprintf('data/PsychoPyLogs/sub%02i.xlsx', subject);
disp(['Reading PsychoPy data for subject ', int2str(subject)])


trials = 160;
trialsPerRun = 32;
runs = 5;
conditions = 8;
[psychopyLog, psychopyText] = xlsread ([cfg.baseDir, filename], 'A2:M161');
for trial = 1 : trials
    psychopyLog (trial, 14) = (psychopyLog(trial, 4)-1) * 4 +psychopyLog(trial, 5);
end

nans = [1, 33, 65, 97, 129];
for ind = nans
        psychopyLog(ind, 2) = 0;
end

%% Build Onset Matrix

% onsetMatrix = zeros(runs, 4, conditions);
% 
% conditionName = {'BOD', 'BOC', 'BPK', 'BPR', 'SOD', 'SOC', 'SPK', 'SPR', 'IMG1', 'IMG2','IMG3','IMG4'};
% 
% for condition = 1 : conditions
%     nextRun = trialsPerRun;
%     index = 1;
%     run = 1;
%     for trial = 1 : trials
%         if psychopyLog(trial, 6) == psychopyLog(trial, 7) % Only the correct answers
%             if psychopyLog(trial, 14) == condition
%                 onsetMatrix(run, index, condition) = (psychopyLog (trial, 3)/1000);
%                 index = index + 1;
%             end;
%         end;
%         if trial == nextRun
%             run = run + 1;
%             index = 1;
%             nextRun = nextRun + trialsPerRun;
%         end;
%     end;
% end;
% 
% for trial = 1 : trials
%     if psychopyLog(trial, 4) == 1; % Condition 1
%         if psychopyLog(trial, 5) < 3;
%             psychopyLog(trial, 9) = 1;
%         else
%             psychopyLog(trial, 9) = 2;
%         end;
%     else
%         if psychopyLog(trial, 5) == 1 || psychopyLog(trial, 5) ==4
%             psychopyLog(trial, 9) = 4;
%         else
%             psychopyLog(trial, 9) = 3;
%         end 
%     end
% end
% 
% for trial = 1 : length(psychopyText)
%     if strcmp(psychopyText(trial), 'breakfast1' ) == 1
%         psychopyLog(trial, 9) = 1;
%     elseif strcmp(psychopyText(trial), 'breakfast2' ) == 1
%         psychopyLog(trial, 9) = 2;
%     elseif strcmp(psychopyText(trial), 'supermarket1' ) == 1
%         psychopyLog(trial, 9) = 3;
%     elseif strcmp(psychopyText(trial), 'supermarket2' ) == 1
%         psychopyLog(trial, 9) = 4;
%     end
% end
% 
% 
% for image = 1 : 4
%     nextRun = trialsPerRun;
%     run = 1;
%     index = 1;
%     for trial = 1 : trials
%         if psychopyLog(trial, 9) == image
%             onsetMatrix(run, index, image+8) = psychopyLog (trial, 2)/1000 + 0.1;
%             index = index + 1;
%         end;
%         if trial == nextRun
%             run = run + 1;
%             index = 1;
%             nextRun = nextRun + trialsPerRun;
%         end;
%     end;
% end
% 
% duration = [6 6 6 6 6 6 6 6 4 4 4 4];



%% Build OnsetMatrix with selected files

onsetMatrix = zeros(runs, 3, conditions);
conditionName = {'BOD', 'BOC', 'BPK', 'BPR', 'SOD', 'SOC', 'SPK', 'SPR', 'IMG1', 'IMG2','IMG3','IMG4'};

%Load trial selection
selectedTrialsAllSubjects = dir ([cfg.baseDir, 'selected_trials10/*.mat']);
sub_ind = find(cfg.subsToDo==31);

% Fill the matrix
for condition = 1 : 8
    
    load([cfg.baseDir, 'selected_trials10/', selectedTrialsAllSubjects(sub_ind).name], 'data')
    for run = 1 : 5
        for trial = 1 : length(data.Sess(run).U(condition).trialnr)
            onsetMatrix(run, trial, condition) = data.Sess(run).U(condition).onset(trial);
        end
    end
end
    
duration = [6 6 6 6 6 6 6 6];

%% Build matlab batch file

clear matlabbatch;

matlabbatch{1}.spm.stats.fmri_spec.dir = {outputDir};
matlabbatch{1}.spm.stats.fmri_spec.timing.units = 'secs';
matlabbatch{1}.spm.stats.fmri_spec.timing.RT = 2;
matlabbatch{1}.spm.stats.fmri_spec.timing.fmri_t = 16; % ?
matlabbatch{1}.spm.stats.fmri_spec.timing.fmri_t0 = 8; % ?

for run = 1 : runs
    runDir = sprintf([subDir, 'run%01i/'], run);
    matlabbatch{1}.spm.stats.fmri_spec.sess(run).scans =  cellstr(spm_select('FPList', runDir, '^auf.*.nii$')); %select files    

    for condition = 1 : conditions
        matlabbatch{1}.spm.stats.fmri_spec.sess(run).cond(condition).name = conditionName{condition};
        matlabbatch{1}.spm.stats.fmri_spec.sess(run).cond(condition).onset = nonzeros(onsetMatrix(run,:,condition));
        matlabbatch{1}.spm.stats.fmri_spec.sess(run).cond(condition).duration = duration(condition);
        matlabbatch{1}.spm.stats.fmri_spec.sess(run).cond(condition).tmod = 0;
        matlabbatch{1}.spm.stats.fmri_spec.sess(run).cond(condition).pmod = struct('name', {}, 'param', {}, 'poly', {});
        matlabbatch{1}.spm.stats.fmri_spec.sess(run).cond(condition).orth = 1;
    end;
    
    % Load movement parameters as regressors
    regressor = dir([runDir, 'rp*.txt']);
    matlabbatch{1}.spm.stats.fmri_spec.sess(run).multi_reg = {[runDir, regressor.name]};
    matlabbatch{1}.spm.stats.fmri_spec.sess(run).hpf = 128;
end
matlabbatch{1}.spm.stats.fmri_spec.fact = struct('name', {}, 'levels', {});
matlabbatch{1}.spm.stats.fmri_spec.bases.hrf.derivs = [0 0];
matlabbatch{1}.spm.stats.fmri_spec.volt = 1;
matlabbatch{1}.spm.stats.fmri_spec.global = 'None';
matlabbatch{1}.spm.stats.fmri_spec.mthresh = 0.8;
matlabbatch{1}.spm.stats.fmri_spec.mask = {''};
matlabbatch{1}.spm.stats.fmri_spec.cvi = 'AR(1)';


%% model estimation


matlabbatch{2}.spm.stats.fmri_est.spmmat = {[outputDir 'SPM.mat']};
matlabbatch{2}.spm.stats.fmri_est.method.Classical = 1;


%% Define contrasts

matlabbatch{3}.spm.stats.con.spmmat = {[outputDir 'SPM.mat']};
matlabbatch{3}.spm.stats.con.consess{1}.tcon.name = 'OpenPlace';
matlabbatch{3}.spm.stats.con.consess{1}.tcon.convec = [1 1 -1 -1 1 1 -1 -1 0 0 0 0];
matlabbatch{3}.spm.stats.con.consess{1}.tcon.sessrep = 'repl';

matlabbatch{3}.spm.stats.con.consess{2}.tcon.name = 'BreakfastSupermarket';
matlabbatch{3}.spm.stats.con.consess{2}.tcon.convec = [1 1 1 1 -1 -1 -1 -1 0 0 0 0]; 
matlabbatch{3}.spm.stats.con.consess{2}.tcon.sessrep = 'repl';

matlabbatch{3}.spm.stats.con.consess{3}.tcon.name = 'DrinkCheck';
matlabbatch{3}.spm.stats.con.consess{3}.tcon.convec = [1 -1 0 0 1 -1 0 0 0 0 0 0]; 
matlabbatch{3}.spm.stats.con.consess{3}.tcon.sessrep = 'repl';

matlabbatch{3}.spm.stats.con.consess{4}.tcon.name = 'KeepRid';
matlabbatch{3}.spm.stats.con.consess{4}.tcon.convec = [0 0 1 -1 0 0 1 -1 0 0 0 0 ]; 
matlabbatch{3}.spm.stats.con.consess{4}.tcon.sessrep = 'repl';

matlabbatch{3}.spm.stats.con.delete = 1; % Deletes previous contrasts

%%
spm_jobman('run',matlabbatch)