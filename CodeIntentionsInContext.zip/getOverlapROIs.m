% Determine clusters that overlap with certain ROIs & create statistics for
% those

function getOverlapROIs (cfg)


%% Parameters to select

roi_source = 'AllMarsbarAALs'; % alternatives: 'PickAtlas', 'secLevelCVClusters', 'AllMarsbarAALs'
ps = [.0005]; % .001,  % single voxel threshold
corrections = {'uncorr'}; % 'FWEc05'};

% REMARK: To choose which type to do, select 
% type = {'identity'} % , 'order'}
% below

% Also check whether all regions that you want are switched on

r_ind = 0; % will increase for result


%% LOAD ROIs ORDER All ALLS


OrderAllMarsbarAALsROIs = [];

OrderAllMarsbarAALsROIs.fname = {
    'rMNI_Amygdala_L_roi'
    'rMNI_Amygdala_R_roi'
     'rMNI_Angular_L_roi'
    'rMNI_Angular_R_roi'
    'rMNI_Calcarine_L_roi'
    'rMNI_Calcarine_R_roi'
     'rMNI_Caudate_L_roi'
    'rMNI_Caudate_R_roi'
    'rMNI_Cerebelum_10_L_roi'
    'rMNI_Cerebelum_10_R_roi'
    'rMNI_Cerebelum_3_L_roi'
    'rMNI_Cerebelum_3_R_roi'
    'rMNI_Cerebelum_4_5_L_roi'
    'rMNI_Cerebelum_4_5_R_roi'
    'rMNI_Cerebelum_6_L_roi'
    'rMNI_Cerebelum_6_R_roi'
    'rMNI_Cerebelum_7b_L_roi'
    'rMNI_Cerebelum_7b_R_roi'
    'rMNI_Cerebelum_8_L_roi'
    'rMNI_Cerebelum_8_R_roi'
    'rMNI_Cerebelum_9_L_roi'
    'rMNI_Cerebelum_9_R_roi'
    'rMNI_Cerebelum_Crus1_L_roi'
    'rMNI_Cerebelum_Crus1_R_roi'
    'rMNI_Cerebelum_Crus2_L_roi'
    'rMNI_Cerebelum_Crus2_R_roi'
    'rMNI_Cingulum_Ant_L_roi'
    'rMNI_Cingulum_Ant_R_roi'
    'rMNI_Cingulum_Mid_L_roi'
    'rMNI_Cingulum_Mid_R_roi'
    'rMNI_Cingulum_Post_L_roi'
    'rMNI_Cingulum_Post_R_roi'
    'rMNI_Cuneus_L_roi'
    'rMNI_Cuneus_R_roi'
    'rMNI_Frontal_Inf_Oper_L_roi'
    'rMNI_Frontal_Inf_Oper_R_roi'
    'rMNI_Frontal_Inf_Orb_L_roi'
    'rMNI_Frontal_Inf_Orb_R_roi'
     'rMNI_Frontal_Inf_Tri_L_roi'
    'rMNI_Frontal_Inf_Tri_R_roi'
    'rMNI_Frontal_Med_Orb_L_roi'
    'rMNI_Frontal_Med_Orb_R_roi'
     'rMNI_Frontal_Mid_L_roi'
    'rMNI_Frontal_Mid_Orb_L_roi'
    'rMNI_Frontal_Mid_Orb_R_roi'
    'rMNI_Frontal_Mid_R_roi'
     'rMNI_Frontal_Sup_L_roi'
    'rMNI_Frontal_Sup_Medial_L_roi'
    'rMNI_Frontal_Sup_Medial_R_roi'
    'rMNI_Frontal_Sup_Orb_L_roi'
    'rMNI_Frontal_Sup_Orb_R_roi'
    'rMNI_Frontal_Sup_R_roi'
    'rMNI_Fusiform_L_roi'
    'rMNI_Fusiform_R_roi'
    'rMNI_Heschl_L_roi'
    'rMNI_Heschl_R_roi'
    'rMNI_Hippocampus_L_roi'
    'rMNI_Hippocampus_R_roi'
    'rMNI_Insula_L_roi'
    'rMNI_Insula_R_roi'
    'rMNI_Lingual_L_roi'
    'rMNI_Lingual_R_roi'
    'rMNI_Occipital_Inf_L_roi'
    'rMNI_Occipital_Inf_R_roi'
    'rMNI_Occipital_Mid_L_roi'
    'rMNI_Occipital_Mid_R_roi'
    'rMNI_Occipital_Sup_L_roi'
    'rMNI_Occipital_Sup_R_roi'
    'rMNI_Olfactory_L_roi'
    'rMNI_Olfactory_R_roi'
    'rMNI_Pallidum_L_roi'
    'rMNI_Pallidum_R_roi'
    'rMNI_ParaHippocampal_L_roi'
    'rMNI_ParaHippocampal_R_roi'
    'rMNI_Paracentral_Lobule_L_roi'
    'rMNI_Paracentral_Lobule_R_roi'
    'rMNI_Parietal_Inf_L_roi'
    'rMNI_Parietal_Inf_R_roi'
    'rMNI_Parietal_Sup_L_roi'
    'rMNI_Parietal_Sup_R_roi'
    'rMNI_Postcentral_L_roi'
    'rMNI_Postcentral_R_roi'
    'rMNI_Precentral_L_roi'
    'rMNI_Precentral_R_roi'
    'rMNI_Precuneus_L_roi'
    'rMNI_Precuneus_R_roi'
    'rMNI_Putamen_L_roi'
    'rMNI_Putamen_R_roi'
    'rMNI_Rectus_L_roi'
    'rMNI_Rectus_R_roi'
    'rMNI_Rolandic_Oper_L_roi'
    'rMNI_Rolandic_Oper_R_roi'
    'rMNI_Supp_Motor_Area_L_roi'
    'rMNI_Supp_Motor_Area_R_roi'
    'rMNI_SupraMarginal_L_roi'
    'rMNI_SupraMarginal_R_roi'
    'rMNI_Temporal_Inf_L_roi'
    'rMNI_Temporal_Inf_R_roi'
    'rMNI_Temporal_Mid_L_roi'
    'rMNI_Temporal_Mid_R_roi'
    'rMNI_Temporal_Pole_Mid_L_roi'
    'rMNI_Temporal_Pole_Mid_R_roi'
    'rMNI_Temporal_Pole_Sup_L_roi'
    'rMNI_Temporal_Pole_Sup_R_roi'
    'rMNI_Temporal_Sup_L_roi'
    'rMNI_Temporal_Sup_R_roi'
    'rMNI_Thalamus_L_roi'
    'rMNI_Thalamus_R_roi'
    'rMNI_Vermis_10_roi'
    'rMNI_Vermis_1_2_roi'
    'rMNI_Vermis_3_roi'
    'rMNI_Vermis_4_5_roi'
    'rMNI_Vermis_6_roi'
    'rMNI_Vermis_7_roi'
    'rMNI_Vermis_8_roi'
    'rMNI_Vermis_9_roi'
     };
OrderAllMarsbarAALsROIs.dir = [cfg.baseDir, 'ROIsMNI/marsbar_aal/'];

for fname = OrderAllMarsbarAALsROIs.fname'

    roifull = fullfile(OrderAllMarsbarAALsROIs.dir, [fname{1} '.nii']);
    
    display(['Loading ' roifull]);
    fieldname = fname{1};
    fieldname(fieldname == '-') = 'm';
    OrderAllMarsbarAALsROIs.(fieldname) = spm_vol(roifull);
    OrderAllMarsbarAALsROIs.(fieldname).vol = spm_read_vols(OrderAllMarsbarAALsROIs.(fieldname));
end

%% Load stuff from AllMarsbarAALs IDENTITY

IdentityAllMarsbarAALsROIs = OrderAllMarsbarAALsROIs;


%% load all CV results

CVresults = [];
for corr_ind = 1:length(corrections)
    correction = corrections{corr_ind};
    for p_ind = 1:length(ps)
        p = ps(p_ind);
        for condition = cfg.conditionNames
            condition = condition{1};
            rpath = [cfg.baseDir, 'secondLevel/', cfg.condition,'/'];

            %% get 2nd level images

            for sub_ind = 1:length(cfg.subsToDo)
                subject = cfg.subsToDo(sub_ind);
                subdir = [rpath, 'sub', num2str(subject, '%02i'),'/significantClusters/'];

                d = dir(fullfile(subdir, 'allClusters.nii'));
                

                % check that it's unique
                if length(d)~=1
                    display(['Could not uniquely get image of subject ' num2str(subject) cfg.conditionNames(condition) 'please check'])
                    error()
                end

                curr_cv = [];
                % check that it does not contain kInf  (then there is no result)
                if findstr('kInf', d.name)
                    display([d.name ' contained kInf, ignoring it'])
                    % also, k1. wont work
                elseif findstr('k1.', d.name)
                    display([d.name ' contained k1., ignoring it'])
                else
                    % add to list of images
                    display(['Loading CVresult ' d.name, ' of subject ',num2str(subject)])
                    % load volume
                    fname = fullfile(subdir, d.name);
                    hdr = spm_vol(fname);
                    vol = spm_read_vols(hdr);

                    curr_cv.fname = fname;
                    curr_cv.hdr = hdr;
                    curr_cv.vol = vol;
                end

                % put data into struct
                if p == .001
                    CVresults.([condition '_p001_' correction]).(['sub' int2str(subject)]) = curr_cv;
                elseif p == .0005
                    CVresults.([condition '_p0005_' correction]).(['sub' int2str(subject)]) = curr_cv;
                else
                    error('Unkown p')
                end

            end
        end
    end
end

%% getting intersections between rois and CVresults

result = [];
atlasROIs = OrderAllMarsbarAALsROIs;
roi_names = fieldnames(OrderAllMarsbarAALsROIs);
roi_names = roi_names(strmatch('rMNI', roi_names));


result.(['crossReason_' roi_source]) = [];

for condition = cfg.conditionNames
    for corr_ind = 1:length(corrections)
        correction = corrections{corr_ind};
        for p_ind = 1:length(ps)
            p = ps(p_ind);
            
            for roi_name_ind = 1:length(roi_names)
                roi_name = roi_names{roi_name_ind};
                
                % get current ROI
                curr_roi = atlasROIs.(roi_name);
                
                
                % go through all subs
                for sub_ind = 1:length(cfg.subsToDo)
                    subject = cfg.subsToDo(sub_ind);
                    
                    % get result directory
                    
                    respathbase = [cfg.baseDir, 'secondLevel/', condition, '/faROIs/'];
                    result_path.([condition,'_' roi_source]) = respathbase;
                    
                    respath = fullfile(respathbase, sprintf('%s_p%.4f_%s', roi_name, p, correction));
                    mkdir(respath)
                    
                    display(['Writing results to ' respath])
                    
                    % get current CV image
                    if p == .001
                        curr_cv = CVresults.([condition '_p001_' correction]).(['sub' int2str(subject)]);
                    elseif p == .0005
                        curr_cv = CVresults.([condition '_p0005_' correction]).(['sub' int2str(subject)]);
                    else
                        error('Unkown p')
                    end
                    
                    if isempty(curr_cv)
                        display('No CV data for sub%i, %s, %s available, skipping')
                        continue
                    end
                    
                    % get intersection to current ROI
                    intersect_vol = curr_roi.vol & curr_cv.vol;
                    size_vox_AAL_total = sum(curr_roi.vol(:));
                    size_vox_currcv_total = sum(curr_cv.vol(:));
                    
                    % check if any none-0 voxels exist
                    [dummy, cv_file] = fileparts(curr_cv.fname);
                    [dummy, roi_file] = fileparts(curr_roi.fname);
                    if any(intersect_vol(:))
                        n_vox = sum(intersect_vol(:));
                        display(sprintf('N=%i voxels overlap between%s and %s', n_vox, cv_file, roi_file))
                        
                        % save overlap in ROIAnalysis folder
                        res_filename = fullfile(respath, sprintf('overlap_%s_%s_sub%02i.img', cv_file, roi_file, subject));
                        
                        display(sprintf('Saving result to %s', res_filename));
                        res_hdr = curr_cv.hdr;
                        res_hdr.fname = res_filename;
                        res_hdr.descrip = sprintf('overlap_%s_%s_sub%02i', cv_file, roi_file, subject);
                        
                        spm_write_vol(res_hdr, intersect_vol);
                        
                        header = sprintf('%s\\t%s\\t%s\\t%s\\t%s\\t%s\\t%s', 'cv_file', 'roi_file', 'sub', 'n_vox_intersection', 'size_vox_AAL_total', 'size_vox_currcv_total', 'correction');
                        %                    result.(['withinReasonWithinContext_' roi_source]){end+1} = sprintf('%s\\t%s\\t%i\\t%i\\t%i\\t%i\\t%s', cv_file, roi_file, subject, n_vox, size_vox_AAL_total, size_vox_currcv_total, correction);
                        
                    else
                        display(sprintf('No overlaps found between %s and %s', cv_file, roi_file))
                    end
                    
                end
                
            end
        end
    end
end

%% display result so that we can read it

% result csv
% for type_roi_source = fieldnames(result)'
%     type_roi_source = type_roi_source{1};
% 
%     res_path = result_path.(type_roi_source);
%     res_fname = fullfile(res_path, ['CV_result_overlap_2ndLevel_' type_roi_source '_ ' datestr(now, 'yymmdd_HHMMSS') '.csv']);
%     display(['Writing result to ' res_fname])
%     fid = fopen(res_fname, 'wt');
% 
%     fprintf(fid, [header '\n']);
%     for r_ind = 1:length(result.(type_roi_source))
%         fprintf(fid, [result.(type_roi_source){r_ind} '\n']);
%     end
% 
%     fclose(fid);
% end

%%
display('Script done')