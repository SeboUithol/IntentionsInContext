addpath('/Users/SeboUithol/Matlab/NifTI_20140122');
roiMNIDir = '/Users/SeboUithol/Documents/BCAN/IntentionsContext/ROIsMNI/';
spmDir = '/Users/SeboUithol/Matlab/SPM12/';

%atlasFile = [roiMNIDir, 'HarvardOxford-cort-maxprob-thr0-2mm.nii'];
atlasFile = [spmDir, 'tpm/labels_Neuromorphometrics.nii'];

atlas = load_nii (atlasFile);

[dimx, dimy, dimz] = size(atlas.img);


%% Build ROI Prefrontal Gyrus

V1 = atlas;

for x = 1 : dimx
    for y = 1 : dimy
        for z = 1 : dimz
            if V1.img(x, y, z) == 156 || V1.img(x, y, z) == 157
                V1.img(x, y, z) = 1;
            else
                V1.img(x, y, z) = 0;
            end;
        end;
    end;
end;
filename = [roiMNIDir, 'V1.nii'];
save_nii (V1, filename)
clear x
clear y
clear z

middleFrontalGyrus = atlas;

for x = 1 : dimx
    for y = 1 : dimy
        for z = 1 : dimz
            if middleFrontalGyrus.img(x, y, z) == 142 || middleFrontalGyrus.img(x, y, z) == 143
                middleFrontalGyrus.img(x, y, z) = 1;
            else
                middleFrontalGyrus.img(x, y, z) = 0;
            end;
        end;
    end;
end;
filename = [roiMNIDir, 'MNImiddleFrontalGyrus.nii'];
save_nii (middleFrontalGyrus, filename)
clear x
clear y
clear z

BA45 = atlas;

for x = 1 : dimx
    for y = 1 : dimy
        for z = 1 : dimz
            if BA45.img(x, y, z) == 165
                BA45.img(x, y, z) = 1;
            else
                BA45.img(x, y, z) = 0;
            end;
        end;
    end;
end;
filename = [roiMNIDir, 'BA45.nii'];
save_nii (BA45, filename)
clear x
clear y
clear z

superiorParietalLobule = atlas;

for x = 1 : dimx
    for y = 1 : dimy
        for z = 1 : dimz
            if superiorParietalLobule.img(x, y, z) == 198 || superiorParietalLobule.img(x, y, z) == 199
                superiorParietalLobule.img(x, y, z) = 1;
            else
                superiorParietalLobule.img(x, y, z) = 0;
            end;
        end;
    end;
end;
filename = [roiMNIDir, 'MNIsuperiorParietalLobule.nii'];
save_nii (superiorParietalLobule, filename)
clear x
clear y
clear z
