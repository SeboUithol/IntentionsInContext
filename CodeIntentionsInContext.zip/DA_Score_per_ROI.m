% Produces DA score of each ROI


% First, obtain the average DA of all sets for each subject

cfg.baseDir = baseDir;

% Load ROIs

selectedROIs = { 

    'rMNI_Angular_L_roi'            %1
    'rMNI_Angular_R_roi'            %2
    'rMNI_Calcarine_L_roi'          %3
    'rMNI_Calcarine_R_roi'          %4
    'rMNI_Cingulum_Post_L_roi'      %5
    'rMNI_Cingulum_Post_R_roi'      %6
    'rMNI_Hippocampus_L_roi'        %7
    'rMNI_Hippocampus_R_roi'        %8
    'rMNI_ParaHippocampal_L_roi'    %9
    'rMNI_ParaHippocampal_R_roi'    %10
    'rMNI_Paracentral_Lobule_L_roi' %11
    'rMNI_Paracentral_Lobule_R_roi' %12
    'rMNI_Parietal_Inf_L_roi'       %13
    'rMNI_Parietal_Inf_R_roi'       %14
    'rMNI_Parietal_Sup_L_roi'       %15
    'rMNI_Parietal_Sup_R_roi'       %16
    'rMNI_Postcentral_L_roi'        %17
    'rMNI_Postcentral_R_roi'        %18
    'rMNI_SupraMarginal_L_roi'      %19
    'rMNI_SupraMarginal_R_roi'      %20
    'rMNI_Temporal_Inf_L_roi'       %21
    'rMNI_Temporal_Inf_R_roi'       %22
    'rMNI_Temporal_Mid_L_roi'       %23
    'rMNI_Temporal_Mid_R_roi'       %24
    'rMNI_Temporal_Pole_Mid_L_roi'  %25
    'rMNI_Temporal_Pole_Mid_R_roi'  %26
    'rMNI_Temporal_Pole_Sup_L_roi'  %27
    'rMNI_Temporal_Pole_Sup_R_roi'  %28
    'rMNI_Temporal_Sup_L_roi'       %29
    'rMNI_Temporal_Sup_R_roi'       %30
     };

% Initialize volume
fileName = [baseDir, 'secondLevel/sameReasonSameContext/subject', num2str(subsToDo(1), '%02i'),'/binary__p0.0010_uncorr.nii'];
hdr = spm_vol(fileName);
roiMap = zeros(hdr.dim); %spm_read_vols(hdr);

roiDir = [baseDir, 'ROIsMNI/marsbar_aal/'];

for roi = 1 : length(selectedROIs)

    % 
    DA_score = nanmean(results(:,1,roi)) / 10; % mean DA across subjects
    
    %load ROI

    fileName = [roiDir, 'rMNI_', selectedROIs{roi}, '.nii'];
    curr_hdr = spm_vol(fileName);
    vol = spm_read_vols(curr_hdr);
    vol = vol * DA_score; % multiplied with its DA score
    roiMap = roiMap + vol; % add to existing map 
end

% save cluster
clusterDir = [baseDir, 'secondLevel/sameReasonSameContext/'];
fileName = 'DAperROI.nii';
display(['Saving result to ', clusterDir, fileName]);
res_hdr = hdr;
res_hdr.fname = [clusterDir, fileName];

spm_write_vol(res_hdr, roiMap);