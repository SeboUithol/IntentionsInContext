function normalizeSmoothDecoding(cfg, subject)



matlabbatch = {};
matlabbatch{1}.spm.spatial.normalise.write.subj.def = cellstr(spm_select('FPList', cfg.structDir, '^y_.*\.nii$'));
matlabbatch{1}.spm.spatial.normalise.write.subj.resample = cellstr(spm_select('FPList', cfg.resultsDir, '^res.*\.nii$')); 
matlabbatch{1}.spm.spatial.normalise.write.woptions.bb = [-78 -112 -70; 78 76 85];
matlabbatch{1}.spm.spatial.normalise.write.woptions.vox = [2 2 2];
matlabbatch{1}.spm.spatial.normalise.write.woptions.interp = 3; 

disp(['converting subject ', int2str(subject), ' to MNI space'])


spm_jobman('run',matlabbatch);


% Smoothing

matlabbatch{2}.spm.spatial.smooth.data = cellstr(spm_select('FPList', cfg.resultsDir, '^wres.*\.nii$'));
matlabbatch{2}.spm.spatial.smooth.fwhm = [2 2 2];
matlabbatch{2}.spm.spatial.smooth.dtype = 0;
matlabbatch{2}.spm.spatial.smooth.im = 0;
matlabbatch{2}.spm.spatial.smooth.prefix = 's';

disp(['Smoothing subject ', int2str(subject)]);
disp(['Writing file to ', cfg.resultsDir]);

% spm_jobman('run',matlabbatch);


