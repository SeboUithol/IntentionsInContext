function normalizeDecoding(cfg, subject)


%% Set paths



matlabbatch{1}.spm.spatial.normalise.write.subj.def(1) = cellstr(spm_select('FPList', cfg.structDir, '^y_.*\.nii$'));

matlabbatch{1}.spm.spatial.normalise.write.subj.resample =  cellstr(spm_select('FPList', cfg.results.dir, '^res.*\.nii$'));


matlabbatch{1}.spm.spatial.normalise.write.woptions.bb = [-78 -112 -70; 78 76 85];
matlabbatch{1}.spm.spatial.normalise.write.woptions.vox = [2 2 2];
matlabbatch{1}.spm.spatial.normalise.write.woptions.interp = 7;


spm_jobman('run',matlabbatch);

%load_nii ([resultsDir, 'wres_accuracy_minus_chance.nii']);
