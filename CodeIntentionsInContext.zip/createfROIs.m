% Determine clusters that overlap with certain ROIs & create statistics for
% those

function getOverlapROIs (cfg)


%% Parameters to select

roi_source = 'AllMarsbarAALs'; % alternatives: 'PickAtlas', 'secLevelCVClusters', 'AllMarsbarAALs'
ps = [.0005]; % .001,  % single voxel threshold
corrections = {'uncorr'}; % 'FWEc05'};

% REMARK: To choose which type to do, select 
% type = {'identity'} % , 'order'}
% below

% Also check whether all regions that you want are switched on

r_ind = 0; % will increase for result


%% LOAD ROIs ORDER All ALLS


OrderAllMarsbarAALsROIs = [];

OrderAllMarsbarAALsROIs.fname = cfg.fROIs;
OrderAllMarsbarAALsROIs.dir = [cfg.baseDir, 'ROIsMNI/marsbar_aal/'];

for fname = OrderAllMarsbarAALsROIs.fname'

    roifull = fullfile(OrderAllMarsbarAALsROIs.dir, [fname{1} '.nii']);
    
    display(['Loading ' roifull]);
    fieldname = fname{1};
    fieldname(fieldname == '-') = 'm';
    OrderAllMarsbarAALsROIs.(fieldname) = spm_vol(roifull);
    OrderAllMarsbarAALsROIs.(fieldname).vol = spm_read_vols(OrderAllMarsbarAALsROIs.(fieldname));
end

%% Load stuff from AllMarsbarAALs IDENTITY

IdentityAllMarsbarAALsROIs = OrderAllMarsbarAALsROIs;


%% load all CV results

CVresults = [];


            rpath = [cfg.baseDir, 'secondLevel/', cfg.condition,'/'];

            %% get 2nd level images

           
                d = dir(fullfile(rpath, 'con_0001.nii'));
                

                % check that it's unique
                if length(d)~=1
                    display(['Could not uniquely get image of subject ' num2str(subject) cfg.conditionNames(condition) 'please check'])
                    error()
                end

                curr_cv = [];
                % check that it does not contain kInf  (then there is no result)
                if findstr('kInf', d.name)
                    display([d.name ' contained kInf, ignoring it'])
                    % also, k1. wont work
                elseif findstr('k1.', d.name)
                    display([d.name ' contained k1., ignoring it'])
                else
                    % add to list of images
                    display(['Loading CVresult ' d.name, ' of subject ',num2str(subject)])
                    % load volume
                    fname = fullfile(subdir, d.name);
                    hdr = spm_vol(fname);
                    vol = spm_read_vols(hdr);

                    curr_cv.fname = fname;
                    curr_cv.hdr = hdr;
                    curr_cv.vol = vol;
                end

                % put data into struct
                if p == .001
                    CVresults.([condition '_p001_' correction]).(['sub' int2str(subject)]) = curr_cv;
                elseif p == .0005
                    CVresults.([condition '_p0005_' correction]).(['sub' int2str(subject)]) = curr_cv;
                else
                    error('Unkown p')
                end

%% getting intersections between rois and CVresults

result = [];
atlasROIs = OrderAllMarsbarAALsROIs;
roi_names = fieldnames(OrderAllMarsbarAALsROIs);
roi_names = roi_names(strmatch('rMNI', roi_names));


result.(['crossReason_' roi_source]) = [];
           
            for roi_name_ind = 1:length(roi_names)
                roi_name = roi_names{roi_name_ind};
                
                % get current ROI
                curr_roi = atlasROIs.(roi_name);
                
                
                % go through all subs
                for sub_ind = 1:length(cfg.subsToDo)
                    subject = cfg.subsToDo(sub_ind);
                    
                    % get result directory
                    
                    respathbase = [cfg.baseDir, 'secondLevel/', condition, '/faROIs/'];
                    result_path.([condition,'_' roi_source]) = respathbase;
                    
                    respath = fullfile(respathbase, sprintf('%s_p%.4f_%s', roi_name, p, correction));
                    mkdir(respath)
                    
                    display(['Writing results to ' respath])
                    
                    % get current CV image

                    curr_cv = CVresults.([condition '_p001_' correction]).(['sub' int2str(subject)]);

                    
                    if isempty(curr_cv)
                        display('No CV data for sub%i, %s, %s available, skipping')
                        continue
                    end
                    
                    % get intersection to current ROI
                    intersect_vol = curr_roi.vol & curr_cv.vol;
                    size_vox_AAL_total = sum(curr_roi.vol(:));
                    size_vox_currcv_total = sum(curr_cv.vol(:));
                    
                    % check if any none-0 voxels exist
                    [dummy, cv_file] = fileparts(curr_cv.fname);
                    [dummy, roi_file] = fileparts(curr_roi.fname);
                    if any(intersect_vol(:))
                        n_vox = sum(intersect_vol(:));
                        display(sprintf('N=%i voxels overlap between%s and %s', n_vox, cv_file, roi_file))
                        
                        % save overlap in ROIAnalysis folder
                        res_filename = fullfile(respath, sprintf('overlap_%s_%s_sub%02i.img', cv_file, roi_file, subject));
                        
                        display(sprintf('Saving result to %s', res_filename));
                        res_hdr = curr_cv.hdr;
                        res_hdr.fname = res_filename;
                        res_hdr.descrip = sprintf('overlap_%s_%s_sub%02i', cv_file, roi_file, subject);
                        
                        spm_write_vol(res_hdr, intersect_vol);
                        
                        header = sprintf('%s\\t%s\\t%s\\t%s\\t%s\\t%s\\t%s', 'cv_file', 'roi_file', 'sub', 'n_vox_intersection', 'size_vox_AAL_total', 'size_vox_currcv_total', 'correction');
                        %                    result.(['withinReasonWithinContext_' roi_source]){end+1} = sprintf('%s\\t%s\\t%i\\t%i\\t%i\\t%i\\t%s', cv_file, roi_file, subject, n_vox, size_vox_AAL_total, size_vox_currcv_total, correction);
                        
                    else
                        display(sprintf('No overlaps found between %s and %s', cv_file, roi_file))
                    end
                    
                end
                
            end
    


%% display result so that we can read it

% result csv
% for type_roi_source = fieldnames(result)'
%     type_roi_source = type_roi_source{1};
% 
%     res_path = result_path.(type_roi_source);
%     res_fname = fullfile(res_path, ['CV_result_overlap_2ndLevel_' type_roi_source '_ ' datestr(now, 'yymmdd_HHMMSS') '.csv']);
%     display(['Writing result to ' res_fname])
%     fid = fopen(res_fname, 'wt');
% 
%     fprintf(fid, [header '\n']);
%     for r_ind = 1:length(result.(type_roi_source))
%         fprintf(fid, [result.(type_roi_source){r_ind} '\n']);
%     end
% 
%     fclose(fid);
% end

%%
display('Script done')