y = [4.2; 4.6; 5];                  %The data.
s = [.3; .2; .6];                   %The standard deviation.
fHand = figure;
aHand = axes('parent', fHand);
hold(aHand, 'on')
colors = ['b', 'g', 'm', 'o'];
for i = 1:numel(y)
    bar(i, y(i), 'parent', aHand, 'facecolor', colors(i));
end
set(gca, 'XTick', 1:numel(y), 'XTickLabel', {'R0', 'R1', 'R2'})
errorbar(y,s,'r');

%% add last plot: grand average across rois and subjects

colors =    [0, 0.68, 1
             0.17, 0.71, 0.5
             1, 0, 0.6
             1, 0.69, 0.25];
labels = {'same', 'crossReason', 'crossContext', 'crossReasonCrossContext'};

curr_cond_mean = nanmean(mean(results, 3), 1);
curr_cond_var = nanvar(mean(results, 3), 1);
 
n_nans = sum(sum(~isnan(results(:, :, :)), 3), 1);
xlabel(['n=' sprintf('%i ', n_nans)]);
hold on
for condition = 1 : 4
    bar([condition], curr_cond_mean(condition), 'FaceColor', colors(condition,:));
end
set(gca,'xtick', 1:4, 'xticklabel',labels);
title('grand mean');
 
% add CI
hold on
curr_CI = sqrt(curr_cond_var)./sqrt(n_nans) * 1.96; % CI95 = SEM * 1.96
errorbar(curr_cond_mean , curr_CI, '.');

%%

A = [1,2,3,4,5,6,2,3,4,6,1];

figure
hold on

bar([1], A(1),'FaceColor','r');
bar([2:3], A(2:3),'FaceColor','b');
bar([4:7], A(4:7), 'FaceColor','g');
bar([8:11], A(8:11), 'FaceColor','m');