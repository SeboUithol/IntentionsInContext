
%% Analysis parameters

% Define subjects
subjects = 30; % Total number of subjects
skipSubject = [3, 4, 17, 27, 28]; % subjects left out of the analysis

subsToDo = [];
for subject = 1 : subjects
    skip = ismember (subject, skipSubject);
    if skip == 0
        subsToDo(end+1) = subject;
    end;
end;

% define ROIs
rois = { 
        'primaryMotor.nii'
        'middleFrontalGyrus.nii'
        'superiorFrontalGyrus.nii'
        'superiorParietalLobule.nii'
        };

% define baseDir
baseDir = getBaseDir;
cd (baseDir)


%% Cross context classification
for subject = subsToDo
    disp(['Decoding subject ', int2str(subject)])
    decodingIntention_xclasscv_context(baseDir, subject, rois);
end;

%% Convert reults to MNI
for subject = subsToDo
    disp(['Processing subject ', int2str(subject)])
    normalizeDecoding(baseDir, subject, 'results/MVPA_xClassCondition/');
end;

%% Group level analysis for Decoding results
outputDir = 'crossClassification/';
secondLevelAnalysisCrossClass (baseDir, subsToDo, outputDir);


%% Construct confusion matrix using ROIs

confusionMatrixCrossContext(baseDir, subsToDo, rois);


%% Calculate average per ROI
roiSubject=[];
for subject = subsToDo
    allValues = [];
    % load result
    subjectDir = sprintf('/Users/SeboUithol/Documents/BCAN/intentionsContext/data/sub%02i/', subject); 
    decodingResultFile = [subjectDir, 'NIFTI/MVPA_xClassCondition/wres_accuracy_minus_chance.nii'];
    decodingResult = load_nii (decodingResultFile);
    
    % load ROI
    roi = load_nii ([baseDir, 'ROISMNI/motor.nii']);
    
    % create temporary array
    % add value of result for every voxel ~=0 in ROI to array
    % calculate mean of array
    mean
    % put mean value in ROI x subject matrix
    
end;
%% Run T-test on ROIs

[H,P,CI,STATS] = ttest(values, 0.5 ,  'tail', 'right');

