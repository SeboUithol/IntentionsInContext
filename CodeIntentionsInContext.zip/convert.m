function convert(subj)

%% Setting Up

% number of runs
runs = 5;

baseDir = '/Users/SeboUithol/Documents/BCAN/intentionsContext/';  % IMPORTANT!!! Make sure that the same base directory is not used by different processes at the same time
subjectDir = sprintf('/Users/SeboUithol/Documents/BCAN/intentionsContext/data/sub%02i/', subj); 
dicomdir = [subjectDir, 'DICOM/'];
niftidir = [subjectDir, 'NIFTI/'];  
struct_dir = sprintf('%s%s', niftidir, 'T1'); % will be created, if it does not exist
field_dir = sprintf('%s%s', niftidir, 'Fieldmaps');
spm_dir = sprintf('/Users/SeboUithol/Matlab/SPM12');

% 
% %% change to log directory (to save ps files there)
logdir = fullfile(subjectDir, 'log');
mkdir(logdir)
cd(logdir)

%% start spm fmri
%spm fmri

batn=0; % init matlabbatch counter
spm_jobman('initcfg'); % initialise SPM batch mode

%% Add paths 
addpath('/Users/SeboUithol/Matlab/SPM12'); % Add spm
addpath(genpath(baseDir)) % Add analysis

%% Converting

if subj < 10
    subject = ['0', num2str(subj)];
else subject = num2str(subj);
end;



%EPI
for run = 1 : runs
    
    importFolder = [dicomdir, '00', num2str(run+4), '_ep2d_bold_', num2str(run)];
    outputFolder = [niftidir, 'run' num2str(run),'/'];
    mkdir (outputFolder)
    
    matlabbatch{run}.spm.util.import.dicom.data = cellstr(spm_select('FPList', importFolder, '.*dcm$'));
    matlabbatch{run}.spm.util.import.dicom.root = 'flat';
    matlabbatch{run}.spm.util.import.dicom.outdir = {outputFolder};
    matlabbatch{run}.spm.util.import.dicom.protfilter = '.*';
    matlabbatch{run}.spm.util.import.dicom.convopts.format = 'nii';
    matlabbatch{run}.spm.util.import.dicom.convopts.icedims = 0;
end;

%T1
mprageFolder = dir(fullfile(dicomdir, '*MPRAGE'));
if length(mprageFolder) ~= 1
    error('1 MPRAGE folder expected but %i found', length(mprageFolder));
end
importFolder = fullfile(dicomdir, mprageFolder(1).name); %[dicomdir, '/003_MPRAGE'];
outputFolder = [niftidir, 'T1/'];
mkdir (outputFolder)
matlabbatch{runs+1}.spm.util.import.dicom.data = cellstr(spm_select('FPList', importFolder, '.*dcm$'));
matlabbatch{runs+1}.spm.util.import.dicom.root = 'flat';
matlabbatch{runs+1}.spm.util.import.dicom.outdir = {[niftidir, 'T1']};
matlabbatch{runs+1}.spm.util.import.dicom.protfilter = '.*';
matlabbatch{runs+1}.spm.util.import.dicom.convopts.format = 'nii';
matlabbatch{runs+1}.spm.util.import.dicom.convopts.icedims = 0;

%Fieldmaps
importFolder = [subjectDir, 'DICOM/003_gre_field_mapping/'];
outputFolder = [niftidir, 'fieldmapMag/'];
mkdir (outputFolder)
matlabbatch{runs+2}.spm.util.import.dicom.data = cellstr(spm_select('FPList', importFolder, '.*dcm$'));
matlabbatch{runs+2}.spm.util.import.dicom.root = 'flat';
matlabbatch{runs+2}.spm.util.import.dicom.outdir = {outputFolder};
matlabbatch{runs+2}.spm.util.import.dicom.protfilter = '.*';
matlabbatch{runs+2}.spm.util.import.dicom.convopts.format = 'nii';
matlabbatch{runs+2}.spm.util.import.dicom.convopts.icedims = 0;

importFolder = [subjectDir, 'DICOM/004_gre_field_mapping/'];
outputFolder = [niftidir, 'fieldmapPhase/'];
mkdir (outputFolder)
matlabbatch{runs+3}.spm.util.import.dicom.data = cellstr(spm_select('FPList', importFolder, '.*dcm$'));
matlabbatch{runs+3}.spm.util.import.dicom.root = 'flat';
matlabbatch{runs+3}.spm.util.import.dicom.outdir = {outputFolder};
matlabbatch{runs+3}.spm.util.import.dicom.protfilter = '.*';
matlabbatch{runs+3}.spm.util.import.dicom.convopts.format = 'nii';
matlabbatch{runs+3}.spm.util.import.dicom.convopts.icedims = 0;

spm_jobman('run',matlabbatch);


