function combineAALROIs (cfg)

for cl = 1 : length(cfg.clusters)
    % Combine anatomical ROIs into one anatomically defined cluster
    fileName = [cfg.ROIdir, cfg.clusters{cl}.ROIs{1}];
    hdr = spm_vol(fileName);
    vol = spm_read_vols(hdr);
    allROIs = vol;
    
    % Add remaining anatomical rois
    
    for roi = 2 : length(cfg.clusters{cl}.ROIs)
        currentROI = fullfile(cfg.ROIdir, cfg.clusters{cl}.ROIs{roi});
        
        hdr = spm_vol(currentROI);
        vol = spm_read_vols(hdr);
        %     plotimage(vol)
        %     title(currentROI)
        %
             allROIs = allROIs | vol;
        %     plotimage(allROIs)
        %     title(sprintf('After adding %s', fileName))
    end
    
    % save cluster
    res_hdr = hdr;
    res_hdr.fname = [cfg.baseDir, 'data/secondLevel/sameReasonSameContextSet3/', cfg.clusters{cl}.name, '.nii'];
    
    spm_write_vol(res_hdr, allROIs);
end