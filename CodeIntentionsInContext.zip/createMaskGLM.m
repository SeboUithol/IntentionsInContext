function createMaskGLM(subject)

    % load grey matter mask
    T1Path = [dataDir, 'sub', num2str(subject, '%02i'), '/nifti/T1/'];
    tissueFiles = dir([T1Path, 'c*.nii']);

    % load gray matter mask
    hdrGM = spm_vol([T1Path, tissueFiles(1).name]);
    volGM = spm_read_vols(hdrGM);

    % load white matter mask
    hdrWM = spm_vol([T1Path, tissueFiles(2).name]);
    volWM = spm_read_vols(hdrGM);

    % Combine masks

    mask = volWM + volGM;
    mask(mask~=0)=1;

    hdrMask = hdrWM;
    hdrMask.descrip = 'Gray matter and white matter combined';
    hdrMask.fname = [T1Path, 'mask.nii'];
    spm_write_vol(hdrMask, mask);

    % Reslice to resolution functional images
    runDir = [dataDir, 'sub', num2str(subject, '%02i'), '/nifti/run1/'];
    funcScans = dir([runDir, 'uM*.nii']);
    funcScan = funcScans(1).name;

    clear matlabbatch
    matlabbatch{1}.spm.spatial.coreg.write.ref = {[runDir, funcScan]};
    matlabbatch{1}.spm.spatial.coreg.write.source = {hdrMask.fname};
    matlabbatch{1}.spm.spatial.coreg.write.roptions.interp = 4;
    matlabbatch{1}.spm.spatial.coreg.write.roptions.wrap = [0 0 0];
    matlabbatch{1}.spm.spatial.coreg.write.roptions.mask = 0;
    matlabbatch{1}.spm.spatial.coreg.write.roptions.prefix = 'r';

    spm_jobman('run',matlabbatch); 

end